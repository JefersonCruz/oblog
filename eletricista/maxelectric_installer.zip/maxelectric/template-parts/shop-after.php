		</div><!-- content-area + page_layout_css -->

		<?php get_sidebar("wc"); ?>

	</div><!-- .container /- -->

</main><!-- .site-main -->

<?php get_footer(); ?>