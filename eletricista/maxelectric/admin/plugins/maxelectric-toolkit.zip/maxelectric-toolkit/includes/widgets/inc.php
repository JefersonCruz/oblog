<?php
/* Widget Register / UN-register */
function maxelectric_manage_widgets() {

	/* Recent News */
	require_once("recent_news.php");
	
	/* About Us */
	require_once("aboutus.php");
	
	/* Information  */
	require_once("information.php");

	register_widget( 'Maxelectric_Widget_AboutUs' );
	
	register_widget( 'Maxelectric_Widget_RecentNews' );
	
	register_widget( 'Maxelectric_Widget_Information' );

}
add_action( 'widgets_init', 'maxelectric_manage_widgets' );