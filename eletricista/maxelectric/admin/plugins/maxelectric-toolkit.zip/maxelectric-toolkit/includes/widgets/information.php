<?php
/**
 * ImageUpload widget class Maxelectric
 *
 * @since 2.8.0
 */
class Maxelectric_Widget_Information extends WP_Widget {

	public function __construct() {
		
		$widget_ops = array( 'classname' => 'widget_info', 'description' => esc_html( "Our Info Content", "maxelectric-toolkit" ) );

		parent::__construct('information', esc_html('Maxelectric :: Our Info', "maxelectric-toolkit"), $widget_ops);
		
		$this->alt_option_name = 'widget_info';
	}

	public function widget( $args, $instance ) {
		
		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Info', "maxelectric-toolkit" );
		
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );
		
		$subtitle = empty( $instance['subtitle'] ) ? '' : $instance['subtitle'];
		$contact = empty( $instance['contact'] ) ? '' : $instance['contact'];
		$email = empty( $instance['email'] ) ? '' : $instance['email'];
		$worktime = empty( $instance['worktime'] ) ? '' : $instance['worktime'];
	
		echo html_entity_decode( $args['before_widget'] );

		if ( $title ) {
			echo html_entity_decode( $args['before_title'] . $title . $args['after_title'] );
		}
		?>
		<div class="information-text">
			<?php 
				if( $subtitle != "" ) {
					?>
					<p><?php echo esc_attr($subtitle); ?></p>
					<?php
				}
				if( $contact != "" ) {
					?>
					<p>
						<i class="icon icon-Phone2"></i> 
						<span><?php esc_html_e('Tel : ',"maxelectric-toolkit"); ?></span>
						<a href="tel:<?php echo esc_attr(str_replace(" ", "", $contact ) ); ?>" title=":<?php echo esc_attr(str_replace(" ", "", $contact ) ); ?>"> 
							<?php echo esc_attr($contact ); ?> 
						</a>
					</p>
					<?php
				}
				if( $email != "" ) {
					?>
					<p>
						<i class="icon icon-Mail"></i> 
						<span><?php esc_html_e('Email : ',"maxelectric-toolkit"); ?></span>
						<a href="mailto:<?php echo esc_attr($email); ?>" title="<?php echo esc_attr($email); ?>"> 
							<?php echo esc_attr($email); ?>
						</a>
					</p>
					<?php
				}
				if( $worktime != "" ) {
					?>
					<p>
						<i class="icon icon-Time"></i> 
						<span><?php esc_html_e('Working Hours : ',"maxelectric-toolkit"); ?></span> 
						<?php echo esc_attr($worktime); ?>
					</p>
					<?php
				}
			?>
		</div>
		<?php
		
		echo html_entity_decode( $args['after_widget'] );
	}
	
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		
		$instance['subtitle'] = ( ! empty( $new_instance['subtitle'] ) ) ? strip_tags( $new_instance['subtitle'] ) : '';
		$instance['contact'] = ( ! empty( $new_instance['contact'] ) ) ? strip_tags( $new_instance['contact'] ) : '';
		$instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';
		$instance['worktime'] = ( ! empty( $new_instance['worktime'] ) ) ? strip_tags( $new_instance['worktime'] ) : '';
		
		return $instance;
	}

	public function form( $instance ) {
	
		$instance = wp_parse_args( ( array ) $instance, array( 'title' => '', 'add_img' => '', 'contact' => '' ) );

		$title = $instance['title'];
		
		$subtitle	=	empty( $instance['subtitle'] ) ? '' : $instance['subtitle'];
		$contact	=	empty( $instance['contact'] ) ? '' : $instance['contact'];
		$email	=	empty( $instance['email'] ) ? '' : $instance['email'];
		$worktime	=	empty( $instance['worktime'] ) ? '' : $instance['worktime'];
		
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', "maxelectric-toolkit" ); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('title') ); ?>" name="<?php echo esc_html( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('subtitle') ); ?>"><?php esc_html_e('Sub Title:', "maxelectric-toolkit" ); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('subtitle') ); ?>" name="<?php echo esc_html( $this->get_field_name('subtitle') ); ?>" type="text" value="<?php echo esc_attr( $subtitle ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('contact') ); ?>"><?php esc_html_e('Contact No:', "maxelectric-toolkit" ); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('contact') ); ?>" name="<?php echo esc_html( $this->get_field_name('contact') ); ?>" type="text" value="<?php echo esc_attr( $contact ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('email') ); ?>"><?php esc_html_e('Email Address:', "maxelectric-toolkit" ); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('email') ); ?>" name="<?php echo esc_html( $this->get_field_name('email') ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>" /></label></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id('worktime') ); ?>"><?php esc_html_e('Working Time:', "maxelectric-toolkit" ); ?> <input class="widefat" id="<?php echo esc_html( $this->get_field_id('worktime') ); ?>" name="<?php echo esc_html( $this->get_field_name('worktime') ); ?>" type="text" value="<?php echo esc_attr( $worktime ); ?>" /></label></p>
		<?php
	}
}