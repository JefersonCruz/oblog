<?php
/**
 * ReduxFramework Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */

if ( ! class_exists( 'Redux' ) ) {
	return;
}

// This is your option name where all the Redux data is stored.
$opt_name = "maxelectric_option";

// This line is only for altering the demo. Can be easily removed.
$opt_name = apply_filters( 'maxelectric_option/opt_name', $opt_name );

/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
	// TYPICAL -> Change these values as you need/desire
	'opt_name'             => $opt_name,
	// This is where your data is stored in the database and also becomes your global variable name.
	'display_name'         => $theme->get( 'Name' ),
	// Name that appears at the top of your panel
	'display_version'      => $theme->get( 'Version' ),
	// Version that appears at the top of your panel
	'menu_type'            => 'menu',
	//Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
	'allow_sub_menu'       => true,
	// Show the sections below the admin menu item or not
	'menu_title'           => esc_html__( 'Maxelectric Options', "maxelectric" ),
	'page_title'           => esc_html__( 'Maxelectric Options', "maxelectric" ),
	// You will need to generate a Google API key to use this feature.
	// Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
	'google_api_key'       => '',
	// Set it you want google fonts to update weekly. A google_api_key value is required.
	'google_update_weekly' => false,
	// Must be defined to add google fonts to the typography module
	'async_typography'     => true,
	// Use a asynchronous font on the front end or font string
	//'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
	'admin_bar'            => true,
	// Show the panel pages on the admin bar
	'admin_bar_icon'       => 'dashicons-portfolio',
	// Choose an icon for the admin bar menu
	'admin_bar_priority'   => 50,
	// Choose an priority for the admin bar menu
	'global_variable'      => '',
	// Set a different name for your global variable other than the opt_name
	'dev_mode'             => false,
	// Show the time the page took to load, etc
	'update_notice'        => true,
	// If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
	'customizer'           => true,
	// Enable basic customizer support
	//'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
	//'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

	// OPTIONAL -> Give you extra features
	'page_priority'        => null,
	// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
	'page_parent'          => 'themes.php',
	// For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	'page_permissions'     => 'manage_options',
	// Permissions needed to access the options panel.
	'menu_icon'            => '',
	// Specify a custom URL to an icon
	'last_tab'             => '',
	// Force your panel to always open to a specific tab (by id)
	'page_icon'            => 'icon-themes',
	// Icon displayed in the admin panel next to your menu_title
	'page_slug'            => '',
	// Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
	'save_defaults'        => true,
	// On load save the defaults to DB before user clicks save or not
	'default_show'         => false,
	// If true, shows the default value next to each field that is not the default value.
	'default_mark'         => '',
	// What to print by the field's title if the value shown is default. Suggested: *
	'show_import_export'   => true,
	// Shows the Import/Export panel when not used as a field.

	// CAREFUL -> These options are for advanced use only
	'transient_time'       => 60 * MINUTE_IN_SECONDS,
	'output'               => true,
	// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
	'output_tag'           => true,
	// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
	// 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

	// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
	'database'             => '',
	// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
	'use_cdn'              => true,
	// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

	// HINTS
	'hints'                => array(
		'icon'          => 'el el-question-sign',
		'icon_position' => 'right',
		'icon_color'    => 'lightgray',
		'icon_size'     => 'normal',
		'tip_style'     => array(
			'color'   => 'red',
			'shadow'  => true,
			'rounded' => false,
			'style'   => '',
		),
		'tip_position'  => array(
			'my' => 'top left',
			'at' => 'bottom right',
		),
		'tip_effect'    => array(
			'show' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'mouseover',
			),
			'hide' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'click mouseleave',
			),
		),
	)
);

Redux::setArgs( $opt_name, $args );

// If Redux is running as a plugin, this will remove the demo notice and links
add_action( 'redux/loaded', 'maxelectric_remove_demo' );

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'General Settings', "maxelectric" ),
	'icon'         => 'fa fa-cogs',
	'id'         => 'general_settings',
	'fields'     => array(
		array(
			'id'       => 'info_siteloader',
			'type'     => 'info',
			'title'    => esc_html__( 'Site Loader', 'maxelectric' ),
		),
		array(
			'id'       => 'opt_siteloader',
			'type'     => 'switch',
			'title'    => esc_html__( 'Site Loader', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		array(
			'id'       => 'info_rtl',
			'type'     => 'info',
			'title'    => esc_html__( 'RTL Setting', 'maxelectric' ),
		),
		array(
			'id'       => 'opt_rtl_switch',
			'type'     => 'switch',
			'title'    => esc_html__( 'RTL', 'maxelectric' ),
			'default'  => "0",
			'on'       => 'On',
			'off'      => 'Off',
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Page Header', "maxelectric" ),
	'icon'         => 'fa fa-credit-card-alt',
	'id'         => 'page_header',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'opt_pageheader_img',
			'type'     => 'media',
			'url'      => true,
			'title'          => esc_html__( 'Page Header Image( Default )', 'maxelectric' ),
			'default'  => array( 'url' => esc_url( MAXELECTRIC_LIB ) . 'images/banner-bg.jpg' ),
		),
		array(
			'id'       => 'opt_pageheader_color',
			'type'     => 'color',
			'url'      => true,
			'title'          => esc_html__( 'Title Text Color', 'maxelectric' ),
			'output'   => array( '.page-banner .banner-content h3'),
		),
		array(
			'id'       => 'opt_pageheadersubtxt_color',
			'type'     => 'color',
			'url'      => true,
			'title'          => esc_html__( 'Sub Title Text Color', 'maxelectric' ),
			'output'   => array( '.page-banner .banner-content h3 span'),
		),
		array(
			'id'       => 'opt_pageheaderbg_overlay',
			'type'     => 'color_rgba',
			'title'   => esc_html__( 'Background Overlay', "maxelectric" ),
			'subtitle' => esc_html__( 'Pick a color.', "maxelectric" ),
			'options' => array(
				'show_alpha_only'    => true
			),
			'output'   => array( "background-color" => ".page-banner.custombg_overlay:before" ),
		),
		array(
			'id'        => 'opt_pageheader_height',
			'type'      => 'slider',
			'title'     => esc_html__('Page Header Height', 'maxelectric'),
			'subtitle'       => esc_html__( 'Allow your users to choose minimum height of page header', 'maxelectric' ),
			"default"   => 230,
			"min"       => 230,
			"step"      => 1,
			"max"       => 500,
			'display_value' => 'label'
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html( 'Social Icons', "maxelectric" ),
	'icon'         => 'fa fa-share-alt',
	'id'         => 'social_icons',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'info_social_icon',
			'type'     => 'info',
			'title'          => esc_html__( 'Social Icons', 'maxelectric' ),
		),
		array(
			'id'             => 'opt_social_icons',
			'type'           => 'ow_repeater',
			'textOne'        => true,
			'image'          => false,
			'title'          => esc_html__( 'Social Icon Entries', 'maxelectric' ),
			'subtitle'       => __( '<u>Here you can use css class like following :</u><br><br>- Elegant Icons( "<b>social_facebook</b>" )<br>- Stroke Gap( "<b>icon icon-Like</b>" )<br>- Font Awesome( "<b>fa fa-facebook</b>" )', 'maxelectric' ),
			'placeholder'    => array(
				'textOne'  => "Font Icon CSS Class",
			)
		),
	),
));

/* Google Map */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Google Map', "maxelectric" ),
	'icon' => 'fa fa-map',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'=>'map_api',
			'type' => 'text',
			'title' => esc_html__( 'API Key', "maxelectric" ),
			'desc' => wp_kses( __( '<a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">Get Api Key</a>', "maxelectric" ), array( 'a' => array( 'target' => array(), 'href' => array() ) ) ),
		),
		/* Fields /- */
	),
) );

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Layout Settings', "maxelectric" ),
	'icon'         => 'fa fa-desktop',
	'id'         => 'layout_settings',
	'fields'     => array(
		
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Body Layout', "maxelectric" ),
	'icon'         => 'fa fa-desktop',
	'id'         => 'body_layout',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'info_layout_body',
			'type'     => 'info',
			'title'    => esc_html__( 'Body Layout', 'maxelectric' ),
		),
		array(
			'id'       => 'layout_body',
			'type'     => 'image_select',
			'icon'     => 'fa fa-tasks',
			'title'    => esc_html__( 'Body Layout', "maxelectric" ),
			'options'  => array(
				'fixed' => array(
					'alt' => 'Boxed',
					'img' => esc_url( MAXELECTRIC_LIB ) . 'images/layout/boxed.png'
				),
				'fluid' => array(
					'alt' => 'Full',
					'img' => esc_url( MAXELECTRIC_LIB ) . 'images/layout/full.png'
				),
			),			
			'default'  => 'fixed'
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Sidebar Settings', "maxelectric" ),
	'icon'         => 'fa fa-columns',
	'id'         => 'sidebar_layout',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'info_sidebar_layout',
			'type'     => 'info',
			'title'    => esc_html__( 'Sidebar Layout', 'maxelectric' ),
		),
		array(
			'id'       => 'layout_sidebar',
			'type'     => 'image_select',
			'icon'     => 'fa fa-tasks',
			'title'    => esc_html__( 'Sidebar Settings', "maxelectric" ),
			'options'  => array(
				'right_sidebar' => array(
					'alt' => 'Right Sidebar',
					'img' => esc_url( MAXELECTRIC_LIB ) . 'images/layout/right_side.png'
				),
				'left_sidebar' => array(
					'alt' => 'Left Sidebar',
					'img' => esc_url( MAXELECTRIC_LIB ) . 'images/layout/left_side.png'
				),
				'no_sidebar' => array(
					'alt' => 'No Sidebar',
					'img' => esc_url( MAXELECTRIC_LIB ) . 'images/layout/no_side.png'
				),
			),			
			'default'  => 'right_sidebar'
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Header/Footer', "maxelectric" ),
	'icon'         => 'fa fa-archive',
	'id'         => 'site_headerfooter',
	'fields'     => array(
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Header', "maxelectric" ),
	'icon'         => 'fa fa-credit-card',
	'subsection' => true,
	'id'         => 'site_header',
	'fields'     => array(
		
		array(
			'id'       => 'info_sitelogo',
			'type'     => 'info',
			'notice' => true,
			'style' => 'critical',
			'icon' => 'fa fa-cube',
			'title'    => esc_html__( 'Site Logo', 'maxelectric' ),
			'subtitle' => esc_html__( 'Choose Logo Type', 'maxelectric' ),
		),
		array(
			'id'       => 'opt_logotype',
			'type'     => 'select',
			'title'    => esc_html__( 'Logo Type', "maxelectric" ),
			'options'  => array(
				'1' => 'Site Title',
				'2' => 'Image',
				'3' => 'Custom Text',
			),
			'default'  => '2',
		),
		array(
			'id'             => 'opt_logo_size',
			'type'           => 'dimensions',
			'units'          => array( 'px' ),    // You can specify a unit value. Possible: px, em, %
			'units_extended' => 'true',  // Allow users to select any type of unit
			'title'          => esc_html__( 'Logo (Width/Height) Option', "maxelectric" ),
			'required' => array( 'opt_logotype', '=', '2' ),
		),
		array(
			'id'=>'opt_logoimg',
			'type' => 'media',
			'title' => esc_html__('Logo Upload', "maxelectric" ),
			'required' => array( 'opt_logotype', '=', '2' ),
			'default'  => array( 'url' => esc_url( MAXELECTRIC_LIB ) . 'images/logo.png' ),
		),
		array(
			'id'=>'opt_customtxt',
			'type' => 'text',
			'title' => esc_html__('Custom Text', "maxelectric" ),
			'required' => array( 'opt_logotype', '=', '3' ),
			'default'  => "Maxelectric"
		),
		
		array(
			'id'       => 'opt_top_header',
			'type'     => 'switch',
			'title'    => esc_html__( 'Header Contact Details', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		
		array(
			'id'       => 'opt_header_search',
			'type'     => 'switch',
			'title'    => esc_html__( 'Header Search Form', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		
		array(
			'id'       => 'info_contact_details',
			'type'     => 'info',
			'notice' => true,
			'style' => 'critical',
			'icon' => 'fa fa-phone',
			'title'    => esc_html__( 'Contact Details', 'maxelectric' ),
			'subtitle' => esc_html__( 'Contact Details for Header', 'maxelectric' ),
		),
		array(
			'id'=>'opt_contactno',
			'type' => 'text',
			'title' => esc_html__('Contact Number', "maxelectric" ),
			'default'  => "1234-678-9011",
		),
		array(
			'id'=>'opt_email',
			'type' => 'text',
			'title' => esc_html__('Email Address', "maxelectric" ),
			'default'  => "example@gmail.com",
		),
		array(
			'id'=>'opt_opentime',
			'type' => 'text',
			'title' => esc_html__('Open Time Monday To Saturday', "maxelectric" ),
			'default'  => esc_html__('9:00 - 18:00',"maxelectric"),
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Footer', "maxelectric" ),
	'icon'         => 'fa fa-window-maximize',
	'id'         => 'site_footer',
	'subsection' => true,
	'fields'     => array(
	
		array(
			'id'       => 'opt_footer_copyright',
			'type'     => 'editor',
			'title'    => esc_html__( 'Copyright Text', "maxelectric" ),
			'subtitle' => esc_html__( 'Use any of the features of WordPress editor inside your panel!', "maxelectric" ),
			'default'  => '&copy; Copyright Max Electric [year]. All Rights reserved',
			 'args'   => array(
				'teeny'            => true,
				'textarea_rows'    => 10
			)
		),
	),
));

Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Other Pages', "maxelectric" ),
	'icon'         => 'el el-file',
	'id'         => 'other_pages',
	'fields'     => array(),
));

/* Woocommerce Product Display Column */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Woocommerce Product Display', "maxelectric" ),
	'icon'         => 'fa fa-shopping-cart',
	'id'         => 'wc_display',
	'subsection' => true,
	'fields'     => array(
	
		/* Fields */
		array(
			'id'       => 'opt_wc_column',
			'type'     => 'select',
			'title'    => esc_html__('Select Option', 'maxelectric'), 
			'subtitle' => esc_html__('Display Item In Column Layout', 'maxelectric'),
			'options'  => array(
				'1' => '1 Column',
				'2' => '2 Column',
				'3' => '3 Column',
				'4' => '4 Column',
			),
			'default'  => '4',
		)
		/* Fields /- */
	),
));

/* Blog Post Option */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Blog Option', "maxelectric" ),
	'icon'         => 'fa fa-commenting-o',
	'id'         => 'blog_post',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'opt_post_tags',
			'type'     => 'switch',
			'title'    => esc_html__( 'Tags', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		array(
			'id'       => 'opt_post_category',
			'type'     => 'switch',
			'title'    => esc_html__( 'Categories', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		array(
			'id'       => 'opt_post_author',
			'type'     => 'switch',
			'title'    => esc_html__( 'Author Details', 'maxelectric' ),
			'default'  => "1",
			'on'       => 'On',
			'off'      => 'Off',
		),
		
	),
));

/* 404 Page */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( '404 Page', "maxelectric" ),
	'icon'         => 'fa fa-exclamation-triangle',
	'id'         => 'page_error',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'opt_error_title',
			'type'     => 'text',
			'title'    => esc_html__( 'Content Title', "maxelectric" ),
			'default'  => '404',
		),
		array(
			'id'       => 'opt_error_subtitle',
			'type'     => 'text',
			'title'    => esc_html__( 'Error Sub Title', "maxelectric" ),
			'default'  => 'Oops, This Page Could Not Be Found!',
		),
	),
));

/* Admin Login */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Admin Login Page', "maxelectric" ),
	'icon'         => 'fa fa-lock',
	'id'         => 'page_admin',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'opt_adminlogo',
			'type'     => 'media',
			'title'    => esc_html__( 'Logo Image', "maxelectric" ),
		),
		array(
			'id'       => 'opt_adminbg_color',
			'type'     => 'color',
			'title'    => esc_html__( 'Background Color', "maxelectric" ),
		),
		array(
			'id'       => 'opt_adminbg_img',
			'type'     => 'media',
			'title'    => esc_html__( 'Background Image', "maxelectric" ),
		),
		array(
			'id'       => 'opt_admincolor',
			'type'     => 'color',
			'title'    => esc_html__( 'Text Color', "maxelectric" ),
		),
	),
));

/* Shortcodes */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Shortcodes', "maxelectric" ),
	'id'    => 'shortcode_options',
	'icon'  => 'el el-credit-card',
	'subsection' => false,
	'fields'     => array(
	)
) );

/* About Layout 1 */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'About Layout 1', "maxelectric"),
	'icon'         => 'fa fa-users',
	'id'         => 'aboutone',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_aboutoneleft',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('About Layout 1 Left Content', "maxelectric" ),
			'image'    => false,
			'url'    => false,
			'textOne'    => true,
			'description'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		array(
			'id'       => 'opt_aboutoneright',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('About Layout 1 Right Content', "maxelectric" ),
			'image'    => false,
			'url'    => false,
			'textOne'    => true,
			'description'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* About Layout 2 */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'About Layout 2', "maxelectric"),
	'icon'         => 'fa fa-users',
	'id'         => 'abouttwo',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_about',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('About Layout 2', "maxelectric" ),
			'image'    => false,
			'url'    => false,
			'textOne'    => true,
			'description'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* Team */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Team', "maxelectric"),
	'icon'         => 'fa fa-trophy',
	'id'         => 'team',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_team',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Team', "maxelectric" ),
			'url'    => false,
			'image'    => true,
			'description'    => true,
			'textOne'    => true,
			'textTwo'    => true,
			'textThree'    => true,
			'textFour'    => true,
			'textFive'    => true,
			'textSix'    => true,
			'textSeven'    => true,
			'textEight'    => true,
			'textNine'    => true,
			'textTen'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Designation', "maxelectric" ),
				'textTwo'    => esc_html__('Facebook URL', "maxelectric" ),
				'textThree'    => esc_html__('Twitter URL', "maxelectric" ),
				'textFour'    => esc_html__('Google+ URL', "maxelectric" ),
				'textFive'    => esc_html__('Linkedin URL', "maxelectric" ),
				'textSix'    => esc_html__('Instagram URL', "maxelectric" ),
				'textSeven'    => esc_html__('Skill Title 1', "maxelectric" ),
				'textEight'    => esc_html__('Skill Value 1', "maxelectric" ),
				'textNine'    => esc_html__('Skill Value 2', "maxelectric" ),
				'textTen'    => esc_html__('Skill Value 2', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* Services */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Services', "maxelectric"),
	'icon'         => 'fa fa-server',
	'id'         => 'service',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_service',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Services', "maxelectric" ),
			'image'    => false,
			'url'    => true,
			'textOne'    => true,
			'textTwo'    => true,
			'description'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'textTwo'    => esc_html__('Button Text', "maxelectric" ),
				'url'    => esc_html__('Button URL', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* Why Choose Us */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Why Choose Us ', "maxelectric"),
	'icon'         => 'fa fa-handshake-o',
	'id'         => 'whychoose',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_whychoose',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Why Choose Us', "maxelectric" ),
			'image'    => false,
			'url'    => false,
			'textOne'    => true,
			'description'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'description'    => esc_html__('Description Text', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* Counter  */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Counter/Skill ', "maxelectric"),
	'icon'         => 'fa fa-trophy',
	'id'         => 'counter',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_counter',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Counter/Skill', "maxelectric" ),
			'image'    => false,
			'url'    => false,
			'textOne'    => true,
			'textTwo'    => true,
			'placeholder'    => array(
				'title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Icon Class', "maxelectric" ),
				'textTwo'    => esc_html__('Counter Value', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/*  Testimonial */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Testimonial', "maxelectric"),
	'icon'         => 'fa fa-quote-right',
	'id'         => 'testimonial',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_testimonial',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Testimonial', "maxelectric" ),
			'image'    => true,
			'description'    => true,
			'url'    => false,
			'textOne'    => true,
			'placeholder'    => array(
				'Title'    => esc_html__('Title', "maxelectric" ),
				'textOne'    => esc_html__('Designation', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/*  Client */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Client', "maxelectric"),
	'icon'         => 'fa fa-shield',
	'id'         => 'clients',
	'subsection' => true,
	'fields'     => array(
		/* Fields */
		array(
			'id'       => 'opt_client',
			'type'     => 'ow_repeater', 
			'title'    => esc_html__('Our Client', "maxelectric" ),
			'image'    => true,
			'description'    => false,
			'url'    => true,
			'placeholder'    => array(
				'url'    => esc_html__('URL', "maxelectric" ),
			),
		),
		/* Fields /- */
	)
));

/* Custom Css */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Custom CSS', "maxelectric" ),
	'icon'         => 'fa fa-code',
	'id'         => 'custom_css',
	'subsection' => false,
	'fields'     => array(
		array(
			'id'        => 'custom_css_desktop',
			'type'      => 'ace_editor',
			'title'     => esc_html__('Custom CSS for 992 to Larger Screen Resolution (iPad Landscape & Desktop)', 'maxelectric'),
			'subtitle'  => esc_html__('Paste your CSS code here.', 'maxelectric'),
			'mode'      => 'css',
			'theme'     => 'monokai',
		),
		array(
			'id'        => 'custom_css_tablet',
			'type'      => 'ace_editor',
			'title'     => esc_html__('Custom CSS for 768px to 991px Screen Resolution (iPad Portrait)', 'maxelectric'),
			'subtitle'  => esc_html__('Paste your CSS code here.', 'maxelectric'),
			'mode'      => 'css',
			'theme'     => 'monokai',
		),
		array(
			'id'        => 'custom_css_mobile',
			'type'      => 'ace_editor',
			'icon'     => "fa fa-tasks",
			'title'     => esc_html__('Custom CSS for 767px to Lower Screen Resolution (iPhone Landscape)', 'maxelectric'),
			'subtitle'  => esc_html__('Paste your CSS code here.', 'maxelectric'),
			'mode'      => 'css',
			'theme'     => 'monokai',
		),
	),
));

/* Typography Css */
Redux::setSection( $opt_name, array(
	'title'      => esc_html__( 'Typography', "maxelectric" ),
	'icon'         => 'fa fa-text-height ',
	'id'         => 'site_typography',
	'subsection' => false,
	'fields'     => array(
		array(
			'id'       => 'info_body_font',
			'type'     => 'info',
			'title'    => esc_html__( 'Body Font Settings', 'maxelectric' ),
		),
		array(
			'id'          => 'opt_body_font',
			'type'        => 'typography', 
			'title'       => esc_html__('Body Style', 'maxelectric'),
			'google'      => true, 
			'font-backup' => false,
			'subsets'      => false,
			'text-align'      => false,
			'line-height'      => false,
			'output'      => array('body'),
			'units'       =>'px',
			'subtitle'    => esc_html__('Body Style', 'maxelectric'),
		),
		array(
			'id' => 'notice_critical11',
			'type' => 'info',
			'notice' => true,
			'style' => 'critical',
			'icon' => 'fa fa-font',
			'title' => esc_html__('H1 to H6 Styling', 'maxelectric'),
			'subtitle' => esc_html__('Typography settings H1 to H6 Tags', 'maxelectric'),
		),
		array(
			'id' => 'h1-font',
			'type' => 'typography',
			'title' => esc_html__('H1', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h1',
		),
		array(
			'id' => 'h2-font',
			'type' => 'typography',
			'title' => esc_html__('H2', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h2',
		),
		array(
			'id' => 'h3-font',
			'type' => 'typography',
			'title' => esc_html__('H3', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h3',
		),
		array(
			'id' => 'h4-font',
			'type' => 'typography',
			'title' => esc_html__('H4', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h4',			
		),
		array(
			'id' => 'h5-font',
			'type' => 'typography',
			'title' => esc_html__('H5', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h5',			
		),
		array(
			'id' => 'h6-font',
			'type' => 'typography',
			'title' => esc_html__('H6', 'maxelectric'),
			'subtitle' => esc_html__('Specify the Heading font properties.', 'maxelectric'),
			'google' => true,
			'text-align' =>false,
			'output' => 'h6',
		),
	),
));

/* Documentation */
Redux::setSection( $opt_name, array(
	'title'  => esc_html__( 'Documentation', "maxelectric" ),
	'icon' => 'fa fa-book',
	'subsection' => false,
	'fields'     => array(
		/* Fields */
		array(
			'id'=>'info_link',
			'type' => 'info',
			'notice' => true,
			'icon' => "el el-file",
			'style' => 'critical',
			'title' => wp_kses( __( '<a href="" target="_blank">Read Documentation</a>', "maxelectric" ), array( 'a' => array( 'target' => array(), 'href' => array() ) ) ),
		),
		/* Fields /- */
	),
) );

/**
 * Removes the demo link and the notice of integrated demo from the redux-framework plugin
 */
if ( ! function_exists( 'maxelectric_remove_demo' ) ) {
	function maxelectric_remove_demo() {
		// Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_filter( 'plugin_row_meta', array(
				ReduxFrameworkPlugin::instance(),
				'plugin_metalinks'
			), null, 2 );

			// Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
		}
	}
}