<?php
/* Redux Options */
if( !function_exists('maxelectric_options') ) :

	function maxelectric_options( $option, $arr = null ) {

		global $maxelectric_option;

		if( $arr ) {

			if( isset( $maxelectric_option[$option][$arr] ) ) {
				return $maxelectric_option[$option][$arr];
			}
		}
		else {
			if( isset( $maxelectric_option[$option] ) ) {
				return $maxelectric_option[$option];
			}
		}
	}

endif;

/* WPAUTOP Allow Html Tags */
if( ! function_exists('maxelectric_shortcode_allowhtmltags') ) {
	
	function maxelectric_shortcode_allowhtmltags() {

		$maxelectric_allowed_tags = array(
			'a' => array(
				'class' => array(),
				'href'  => array(),
				'rel'   => array(),
				'title' => array(),
			),
			'abbr' => array(
				'title' => array(),
			),
			'b' => array(),
			'blockquote' => array(
				'cite'  => array(),
			),
			'cite' => array(
				'title' => array(),
			),
			'code' => array(),
			'del' => array(
				'datetime' => array(),
				'title' => array(),
			),
			'dd' => array(),
			'dl' => array(),
			'dt' => array(),
			'em' => array(),
			'h1' => array(),
			'h2' => array(),
			'h3' => array(),
			'h4' => array(),
			'h5' => array(),
			'h6' => array(),
			'i' => array(),
			'img' => array(
				'alt'    => array(),
				'class'  => array(),
				'height' => array(),
				'src'    => array(),
				'width'  => array(),
			),
			'li' => array(
				'class' => array(),
			),
			'ol' => array(
				'class' => array(),
			),
			'p' => array(
				'class' => array(),
			),
			'q' => array(
				'cite' => array(),
				'title' => array(),
			),
			'span' => array(
				'class' => array(),
				'title' => array(),
				'style' => array(),
			),
			'strong' => array(),
			'ul' => array(
				'class' => array(),
			),
		);
		
		return $maxelectric_allowed_tags;
	}
}
?>