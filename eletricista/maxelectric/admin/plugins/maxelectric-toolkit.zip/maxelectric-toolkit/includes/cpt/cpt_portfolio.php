<?php
/* CPT : Portfolio */
if ( ! function_exists('maxelectric_cpt_portfolio') ) {

	add_action( 'init', 'maxelectric_cpt_portfolio', 0 );

	function maxelectric_cpt_portfolio() {

		$labels = array(
			'name' =>  esc_html__('Portfolio', "maxelectric-toolkit" ),
			'singular_name' => esc_html__('Portfolio', "maxelectric-toolkit" ),
			'add_new' => esc_html__('Add New', "maxelectric-toolkit" ),
			'add_new_item' => esc_html__('Add New Portfolio', "maxelectric-toolkit" ),
			'edit_item' => esc_html__('Edit Portfolio', "maxelectric-toolkit" ),
			'new_item' => esc_html__('New Portfolio', "maxelectric-toolkit" ),
			'all_items' => esc_html__('All Portfolio', "maxelectric-toolkit" ),
			'view_item' => esc_html__('View Portfolio', "maxelectric-toolkit" ),
			'search_items' => esc_html__('Search Portfolio', "maxelectric-toolkit" ),
			'not_found' =>  esc_html__('No Portfolio found', "maxelectric-toolkit" ),
			'not_found_in_trash' => esc_html__('No Portfolio found in Trash', "maxelectric-toolkit" ),
			'parent_item_colon' => '',
			'menu_name' => esc_html__('Portfolio', "maxelectric-toolkit")
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true, 
			'show_in_menu' => true, 
			'query_var' => true,
			'supports' => array( 'title','thumbnail','editor'),
			'rewrite'  => array( 'slug' => 'portfolio-item' ),
			'has_archive' => false, 
			'capability_type' => 'post', 
			'hierarchical' => false,
			'menu_position' => 106,
			'menu_icon' => 'dashicons-images-alt2',
		);
		register_post_type( 'maxele_portfolio', $args );
	}
}
/* Register Custom Taxonomy */
add_action( 'init', 'maxelectric_tax_portfolio', 1 );
function maxelectric_tax_portfolio() {

	$labels = array(
		'name'                       => _x( 'Portfolio Categories', 'Taxonomy General Name', 'maxelectric-toolkit' ),
		'singular_name'              => _x( 'Portfolio Categories', 'Taxonomy Singular Name', 'maxelectric-toolkit' ),
		'menu_name'                  => esc_html__( 'Portfolio Category', 'maxelectric-toolkit' ),
		'all_items'                  => esc_html__( 'All Items', 'maxelectric-toolkit' ),
		'parent_item'                => esc_html__( 'Parent Item', 'maxelectric-toolkit' ),
		'parent_item_colon'          => esc_html__( 'Parent Item:', 'maxelectric-toolkit' ),
		'new_item_name'              => esc_html__( 'New Item Name', 'maxelectric-toolkit' ),
		'add_new_item'               => esc_html__( 'Add New Item', 'maxelectric-toolkit' ),
		'edit_item'                  => esc_html__( 'Edit Item', 'maxelectric-toolkit' ),
		'update_item'                => esc_html__( 'Update Item', 'maxelectric-toolkit' ),
		'view_item'                  => esc_html__( 'View Item', 'maxelectric-toolkit' ),
		'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'maxelectric-toolkit' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove items', 'maxelectric-toolkit' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'maxelectric-toolkit' ),
		'popular_items'              => esc_html__( 'Popular Items', 'maxelectric-toolkit' ),
		'search_items'               => esc_html__( 'Search Items', 'maxelectric-toolkit' ),
		'not_found'                  => esc_html__( 'Not Found', 'maxelectric-toolkit' ),
		'items_list'                 => esc_html__( 'Items list', 'maxelectric-toolkit' ),
		'items_list_navigation'      => esc_html__( 'Items list navigation', 'maxelectric-toolkit' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'maxelectric_portfolio_tax', array( 'maxele_portfolio' ), $args );
}
?>