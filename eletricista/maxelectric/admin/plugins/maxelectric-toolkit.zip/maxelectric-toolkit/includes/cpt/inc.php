<?php
/* Include all individual CPT. */
$prefix_cpt = "cpt_";
require_once( $prefix_cpt . "portfolio.php" );
?>