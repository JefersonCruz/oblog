<?php
/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

if( ! function_exists("maxelectric_get_sidebars") ) {

	function maxelectric_get_sidebars() {

		global $wp_registered_sidebars;

		$sidebar_options = array();

		$dwidgetarea = array( "" => "Select an Option" );

		foreach ( $wp_registered_sidebars as $sidebar ) {
			$sidebar_options[$sidebar['id']] = $sidebar['name'];
		}
		return array_merge( $dwidgetarea, $sidebar_options );
	}
}
add_action( 'cmb2_init', 'register_maxelectric_metabox' );
/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_init' hook.
 */
function register_maxelectric_metabox() {

	// Start with an underscore to hide fields from custom fields list
	$prefix = 'maxelectric_cf_';

	/* ## Page/Post Options ---------------------- */

	/* - Page Description */
	$cmb_page = new_cmb2_box( array(
		'id'            => $prefix . 'metabox_page',
		'title'         => esc_html__( 'Page Options', "maxelectric-toolkit" ),
		'object_types'  => array( 'page', 'post', 'product','maxele_portfolio' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
	) );

	$cmb_page->add_field( array(
		'name'             => 'Content Area Padding',
		'desc'             => 'If your content section need to have just after header area without space, please select an option Off',
		'id'               => $prefix . 'content_padding',
		'type'             => 'select',
		'default'          => 'on',
		'options'          => array(
			'on' => esc_html__( 'On', "maxelectric-toolkit" ),
			'off'   => esc_html__( 'Off', "maxelectric-toolkit" ),
		),
	) );

	$cmb_page->add_field( array(
		'name'             => 'Page Layout',
		'desc'             => 'Select an option',
		'id'               => $prefix . 'page_owlayout',
		'type'             => 'radio',
		'default'          => 'none',
		'options'          => array(
			'none' =>  '<img title="Default" src="'. MAXELECTRIC_LIB .'/images/none.png" />',
			'fixed' =>  '<img title="Fixed" src="'. MAXELECTRIC_LIB .'/images/boxed.png" />',
			'fluid' =>  '<img title="Fluid" src="'. MAXELECTRIC_LIB .'/images/full.png" />'
		),
	) );
	
	$cmb_page->add_field( array(
		'name'             => 'Sidebar Position',
		'desc'             => 'Select an option',
		'id'               => $prefix . 'sidebar_owlayout',
		'type'             => 'radio',
		'default'          => 'none',
		'options'          => array(
			'none' =>  '<img src="'. MAXELECTRIC_LIB .'/images/none.png" />',
			'right_sidebar' =>  '<img src="'. MAXELECTRIC_LIB .'/images/right_side.png" />',
			'left_sidebar' =>  '<img src="'. MAXELECTRIC_LIB .'/images/left_side.png" />',
			'no_sidebar' =>  '<img src="'. MAXELECTRIC_LIB .'/images/no_side.png" />',
		),
	) );
	
	$cmb_page->add_field( array(
		'name'             => 'Widget Area',
		'desc'             => 'Select an option',
		'id'               => $prefix . 'widget_area',
		'type'             => 'select',
		'default'          => '',
		'options'          => maxelectric_get_sidebars(),
	) );
	$cmb_page->add_field( array(
		'name'             => 'Page Header',
		'desc'             => 'Select an option',
		'id'               => $prefix . 'page_title',
		'type'             => 'select',
		'default'          => 'enable',
		'options'          => array(
			'enable' => esc_html__( 'Enable', "maxelectric-toolkit" ),
			'disable'   => esc_html__( 'Disable', "maxelectric-toolkit" ),
		),
	) );

	$cmb_page->add_field( array(
		'name' => esc_html__( 'Header Image', "maxelectric-toolkit" ),
		'desc' => esc_html__( 'Upload an image or enter a URL.', "maxelectric-toolkit" ),
		'id'   => $prefix . 'page_header_img',
		'type' => 'file',
	) );

	$cmb_page->add_field( array(
		'name' => esc_html__( 'Sub Title', "maxelectric-toolkit" ),
		'id'   => $prefix . 'page_subtitle',
		'type' => 'text',
	) );
	
	$prefix_cmb = "cmb_";

	/* ## Post Options ---------------------- */
	require_once( $prefix_cmb . "post.php");

	/* ## Portfolio Options ---------------------- */
	require_once( $prefix_cmb . "portfolio.php");	
}


add_action( 'cmb2_init', 'register_maxelectric_user_profile_metabox' );
/**
 * Hook in and add a metabox to add fields to the user profile pages
 */
function register_maxelectric_user_profile_metabox() {
	
	$prefix = 'maxelectric_user_';

	/**
	 * Metabox for the user profile screen
	 */
	$cmb_user = new_cmb2_box( array(
		'id'               => $prefix . 'edit',
		'title'            => esc_html__( 'User Profile Metabox', 'maxelectric-toolkit' ),
		'object_types'     => array( 'user'),
		'show_names'       => true,
		'new_user_section' => 'add-new-user',
	) );

	$cmb_user->add_field( array(
		'name'     => esc_html__( 'Extra Info', 'maxelectric-toolkit' ),
		'id'       => $prefix . 'extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );
	
	$cmb_user->add_field( array(
		'name' => esc_html__( 'Designation', 'maxelectric-toolkit' ),
		'id'   => $prefix . 'userdesig',
		'type' => 'text',
	) );
}
?>