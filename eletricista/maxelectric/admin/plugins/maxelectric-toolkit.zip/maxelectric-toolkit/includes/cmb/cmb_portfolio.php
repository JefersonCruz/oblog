<?php
// Start with an underscore to hide fields from custom fields list
$prefix = 'maxelectric_cf_';

/* Post : maxele_portfolio */
$cmb_portfolio = new_cmb2_box( array(
	'id'            => $prefix . 'metabox_portfolio',
	'title'         => esc_html__( 'Portfolio Options', "maxelectric-toolkit" ),
	'object_types'  => array( 'maxele_portfolio' ), // Post type
	'context'       => 'normal',
	'priority'      => 'high',
	'show_names'    => true, // Show field names on the left
) );
$cmb_portfolio->add_field( array(
	'name' => esc_html__( 'Add Or Upload Image', "maxelectric-toolkit" ),
	'id'   => $prefix . 'single_img',
	'type' => 'file',
) );
$cmb_portfolio->add_field( array(
    'name' => 'Embed Video URL',
    'desc' => 'Enter a youtube, twitter, or instagram URL. Supports services listed at <a href="http://codex.wordpress.org/Embeds">http://codex.wordpress.org/Embeds</a>.',
    'id'   => $prefix .'portfolio_video_embed',
    'type' => 'oembed',
) );
$cmb_grp_portfolio = $cmb_portfolio->add_field( array(
	'id'          => $prefix . 'portfolio_grp',
	'type'        => 'group',
	'options'     => array(
		'group_title'   => esc_html__( 'Project Details {#}', 'maxelectric-toolkit' ), // {#} gets replaced by row number
		'add_button'    => esc_html__( 'Add Item', 'maxelectric-toolkit' ),
		'remove_button' => esc_html__( 'Remove Item', 'maxelectric-toolkit' ),
	),
) );
$cmb_portfolio->add_group_field( $cmb_grp_portfolio, array(
	'name' => 'Icon Class',
	'id'   => 'icon_class',
	'type' => 'text',
) );
$cmb_portfolio->add_group_field( $cmb_grp_portfolio, array(
	'name' => 'Title',
	'id'   => 'single_title',
	'type' => 'text',
) );
$cmb_portfolio->add_group_field( $cmb_grp_portfolio, array(
	'name' => 'Description',
	'id'   => 'single_value',
	'type' => 'text',  
) );
?>