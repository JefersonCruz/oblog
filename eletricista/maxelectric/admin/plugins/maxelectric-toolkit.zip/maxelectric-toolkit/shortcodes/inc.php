<?php
if( !function_exists('maxelectric_sc_setup') ) {
	
	function maxelectric_sc_setup() {
		add_image_size( 'maxelectric_98_80', 98, 80 ,true  ); // Latest News Form
		add_image_size( 'maxelectric_82_82', 82, 82,true  ); // Testimonial
		add_image_size( 'maxelectric_283_283', 283, 283,true ); // Team
		add_image_size( 'maxelectric_117_117', 117, 117,true ); // Team Thum List
		add_image_size( 'maxelectric_360_260', 360, 260,true ); // About US
		add_image_size( 'maxelectric_476_477', 476, 477,true ); // Portfolio Layout 1
		add_image_size( 'maxelectric_570_330', 570, 330,true ); // Blog Post 1
		add_image_size( 'maxelectric_182_162', 182, 162,true ); // Blog Post No post no 1
		add_image_size( 'maxelectric_575_399', 575, 399,true ); // Portfolio layout 2/3 image no 3,5
		add_image_size( 'maxelectric_278_180', 278, 180,true ); // Portfolio layout 2/3 image no 1,2
		add_image_size( 'maxelectric_575_250', 575, 250,true ); // Portfolio layout 2/3 image no 8
		add_image_size( 'maxelectric_575_200', 575, 200,true ); // Portfolio layout 2/3 image no 4
		add_image_size( 'maxelectric_278_150', 278, 150,true ); // Portfolio layout 2/3 image no 6,7
	}
	add_action( 'after_setup_theme', 'maxelectric_sc_setup' );
}
function maxelectric_currentYear( $atts ) {
    return date('Y');
}
add_shortcode( 'year', 'maxelectric_currentYear' );

if( function_exists('vc_map') ) {

	vc_add_param("vc_row", array(
		"type" => "dropdown",
		"group" => "Page Layout",
		"class" => "",
		"heading" => "Type",
		"param_name" => "type",
		'value' => array(
			esc_html__( 'Default', "maxelectric-toolkit" ) => 'default-layout',
			esc_html__( 'Fixed', "maxelectric-toolkit" ) => 'container',
		),
	));
	
	vc_add_param("vc_row", array(
		"type" => "dropdown",
		"group" => "Page Layout",
		"class" => "",
		"heading" => "Section Padding",
		"param_name" => "spadding",
		'value' => array(
			esc_html__( 'No', "maxelectric-toolkit" ) => 'no',
			esc_html__( 'Yes', "maxelectric-toolkit" ) => 'yes',
		),
	));

	/* Include all individual shortcodes. */
	$prefix_sc = "sc_";

	require_once( $prefix_sc . "blog_post.php");
	require_once( $prefix_sc . "service.php");
	require_once( $prefix_sc . "about.php");
	require_once( $prefix_sc . "portfolio.php");
	require_once( $prefix_sc . "product.php");
	require_once( $prefix_sc . "counter.php");
	require_once( $prefix_sc . "calltoaction.php");
	require_once( $prefix_sc . "testimonial.php");
	require_once( $prefix_sc . "whychooseus.php");
	require_once( $prefix_sc . "section_title.php");
	require_once( $prefix_sc . "quoteform.php");
	require_once( $prefix_sc . "team.php");
	require_once( $prefix_sc . "client.php");
	require_once( $prefix_sc . "googlemap.php");
	require_once( $prefix_sc . "contactus.php");
}