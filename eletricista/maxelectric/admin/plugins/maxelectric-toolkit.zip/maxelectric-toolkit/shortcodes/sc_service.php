<?php
function maxelectric_service( $atts ) {
	
	extract( shortcode_atts( array('layout' => 'one', 'sc_title' => '', 'sc_desc' => '' ), $atts ) );
	
	ob_start();
	
	if($layout == 'one') {
		?>
		<!-- Services Section -->
		<div class="services-section no-left-padding no-right-padding container-fluid">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" || $sc_desc != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<?php if( $sc_title != "" ) { ?><h3><?php echo esc_attr($sc_title); ?></h3><?php } ?>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
							<?php echo wpautop( wp_kses( $sc_desc, maxelectric_shortcode_allowhtmltags() ) ); ?>
						</div><!-- Section Header /- -->
						<?php
					}
					?>
					<div class= "row">
					<?php
						if( maxelectric_options("opt_service") != "" ) {
							foreach( maxelectric_options("opt_service") as $single_item ) {
								?>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<div class="srv-box">
										<?php 
											if( $single_item["textOne"] != "" ) {
												?>
												<i class="<?php echo esc_attr($single_item["textOne"] ); ?>"></i>
												<?php
											}
											if( $single_item["title"] != "" ) {
												?>
												<h5><?php echo esc_attr($single_item["title"] ); ?></h5>
												<?php
											}
											echo wpautop( wp_kses( $single_item["description"], maxelectric_shortcode_allowhtmltags() ) );
											
											if($single_item["textTwo"] != "" ) {
												?>
												<a href="<?php echo esc_url($single_item["url"] ); ?>" title="<?php echo esc_attr($single_item["textTwo"] ); ?>"><?php echo esc_attr($single_item["textTwo"] ); ?></a>
												<?php
											}
										?>
									</div>
								</div>
								<?php
							}
						}
						?>
					</div>
			</div><!-- Container /- -->
		</div><!-- Services Section -->
		<?php
	}
	else if($layout == 'two') {
		?>
		<!-- Services Section2 -->
		<div class="services-section services-section2 no-left-padding no-right-padding container-fluid">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" || $sc_desc != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
							<?php echo wpautop( wp_kses( $sc_desc, maxelectric_shortcode_allowhtmltags() ) ); ?>
						</div><!-- Section Header /- -->
						<?php
					}
					?>
					<div class="row">
						<?php
						if( maxelectric_options("opt_service") != "" ) {
							foreach( maxelectric_options("opt_service") as $single_item ) {
								?>
								<div class="col-md-4 col-sm-6 col-xs-6">
									<div class="srv-box">
										<?php 
											if( $single_item["textOne"] != "" ) {
												?>
												<i class="<?php echo esc_attr( $single_item["textOne"] ); ?>"></i>
												<?php
											}
											if( $single_item["title"] != "" ){
												?>
												<h5><?php echo esc_attr($single_item["title"] ); ?></h5>
												<?php
											}
											echo wpautop( wp_kses( $single_item["description"], maxelectric_shortcode_allowhtmltags() ) );
											
											if($single_item["textTwo"] != "" ) {
												?>
												<a href="<?php echo esc_url($single_item["url"] ); ?>" title="<?php echo esc_attr($single_item["textTwo"] ); ?>"><?php echo esc_attr($single_item["textTwo"] ); ?></a>
												<?php
											}
										?>
									</div>
								</div>
								<?php
							}
						}
						?>
				</div>
			</div><!-- Container /- -->
		</div><!-- Services Section2 -->
		<?php
	}
	
	return ob_get_clean();
}

add_shortcode('maxelectric_service', 'maxelectric_service');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_service',
		'name' => esc_html__( 'Service', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select a Layout', "maxelectric-toolkit" ),
				'param_name' => 'layout',
				'description' => esc_html__( 'Default Layout 1 Set', 'maxelectric-toolkit' ),
				'value' => array(
					esc_html__( 'Layout 1', "maxelectric-toolkit" ) => 'one',
					esc_html__( 'Layout 2', "maxelectric-toolkit" ) => 'two',
				),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two' ) ),
			),
			array(
				'type' => 'textarea',
				'heading' => esc_html__( 'Short Description', "maxelectric-toolkit" ),
				'param_name' => 'sc_desc',
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two' ) ),
			),
		),
	) );
}
?>