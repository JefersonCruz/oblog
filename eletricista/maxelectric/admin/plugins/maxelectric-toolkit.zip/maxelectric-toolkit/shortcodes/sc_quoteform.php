<?php
function maxelectric_quoteform( $atts ) {
	
	extract( shortcode_atts( array( 'sc_image' => '', 'sc_title' => '','id' => '' ), $atts ) );
	
	ob_start();
	
	if($sc_image != ""){
		$style = " style='background-image: url(".wp_get_attachment_url( $sc_image ).");'";
	}
	else {
		$style = "";
	}
	
	?>
	<div class="container">
		<div class="form-box">
			<div class="we-are-form"<?php echo html_entity_decode( $style ); ?>>
				<?php 
					if( $sc_title != "" ) { 
						?>
						<h5><?php echo esc_attr($sc_title); ?></h5>
						<?php 
					}
					
					echo do_shortcode('[contact-form-7 id="'.esc_attr( $id ).'"]'); 
				?>
				
			</div>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_quoteform', 'maxelectric_quoteform');

if( function_exists('vc_map') ) {
	
	/**
	 * Add Shortcode To Visual Composer
	*/
	$maxelectric_cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

	$maxelectric_contactforms = array();
	
	if ( $maxelectric_cf7 ) {
		foreach ( $maxelectric_cf7 as $cform ) {
			$maxelectric_contactforms[ $cform->post_title ] = $cform->ID;
		}
	} else {
		$maxelectric_contactforms[ esc_html__( 'No contact forms found', 'maxelectric-toolkit' ) ] = 0;
	}

	vc_map( array(
		'base' => 'maxelectric_quoteform',
		'name' => esc_html__( 'Quote Form', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Image', "maxelectric-toolkit" ),
				'param_name' => 'sc_image',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select Contact Form', 'maxelectric-toolkit' ),
				'param_name' => 'id',
				'value' => $maxelectric_contactforms,
				'save_always' => true,
				'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'maxelectric-toolkit' ),
			),
		),
	) );
}
?>