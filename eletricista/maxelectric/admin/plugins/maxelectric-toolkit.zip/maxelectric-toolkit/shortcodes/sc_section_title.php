<?php
function maxelectric_title( $atts ) {
	
	extract( shortcode_atts( array( 'sc_title' => '' ), $atts ) );
	
	ob_start();
	
	if( $sc_title != "" ) {
		?>
		<div class="no-padding container-fluid full-section-title">
			<!-- Container -->
			<div class="container">
				<!-- Section Header -->
				<div class="section-header">
					<h3><?php echo esc_attr($sc_title); ?></h3>
					<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
				</div><!-- Section Header /- -->
			</div>
		</div>
		<?php
	}
	return ob_get_clean();
}

add_shortcode('maxelectric_title', 'maxelectric_title');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_title',
		'name' => esc_html__( 'Section Title', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
		),
	) );
}
?>