<?php
function maxelectric_blog( $atts ) {
	
	extract( shortcode_atts( array( 'layout' => 'one', 'sc_title' => '', 'posts_display' => '' ), $atts ) );
	
	$ow_post_type = 'post';

	if( '' === $posts_display ) :
		$posts_display = 4;		
	endif;
	
	$qry = new WP_Query( array(
		'post_type' => $ow_post_type,
		'posts_per_page' => $posts_display,
	) );
	
	ob_start();
	
	if($layout == 'one') {
		?>
		<!-- Latest Blog -->
		<div class="latest-blog container-fluid no-left-padding no-right-padding">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
				?>
				<!-- Row -->
				<div class="row">
					<?php
						$post_count = 1;
						while ( $qry->have_posts() ) : $qry->the_post();
							$css = "";
							if( ! has_post_thumbnail() ) {
								$css = ' no_post_thumb';
							}
							if($post_count == 1) {
								?>
								<div class="col-md-6 col-sm-12 col-xs-12">
									<article <?php post_class(); ?>>
										<?php
											if( has_post_thumbnail() ) {
												?>
												<div class="entry-cover">
													<a title="Blog" href="<?php the_permalink(); ?>">
														<?php the_post_thumbnail("maxelectric_570_330"); ?>
													</a>
												</div>
												<?php
											}
										?>
										<h3 class="entry-title">
											<a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">
												<?php the_title(); ?>
											</a>
										</h3>
										<div class="entry-meta">
											<div class="post-date">
												<a href="<?php the_permalink(); ?>" title="<?php echo get_the_date('M j, Y'); ?>"><i class="icon icon-Time"></i><?php echo get_the_date('M j, Y'); ?></a>
											</div>
											<div class="byline">
												<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" title="<?php the_author(); ?>"><i class="icon icon-User"></i><?php the_author(); ?></a>
											</div>
										</div>
										<div class="entry-content">
											<?php echo wpautop( wp_kses( wp_html_excerpt( strip_shortcodes( get_the_content() ), 200, ' [...]' ), maxelectric_shortcode_allowhtmltags() ) ); ?>
											<a href="<?php the_permalink(); ?>" title="<?php esc_html_e('continue reading',"maxelectric-toolkit"); ?>">
												<?php esc_html_e('continue reading',"maxelectric-toolkit"); ?>
											</a>
										</div>
									</article>
								</div>
								<?php
							}
							else {
								?>
								<div class="col-md-6 col-sm-12 col-xs-12 post-right">
									<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
										<?php
											if( has_post_thumbnail() ) {
												?>
												<div class="entry-cover">
													<a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">
														<?php the_post_thumbnail("maxelectric_182_162"); ?>
													</a>
												</div>
												<?php
											}
										?>
										<h3 class="entry-title"><a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
										<div class="entry-meta">
											<div class="post-date">
												<a href="<?php the_permalink(); ?>" title="<?php echo get_the_date('M j, Y'); ?>"><i class="icon icon-Time"></i><?php echo get_the_date('M j, Y'); ?></a>
											</div>
											<div class="byline">
												<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" title="<?php the_author(); ?>"><i class="icon icon-User"></i><?php the_author(); ?></a>
											</div>
										</div>
										<div class="entry-content">
											<?php echo wpautop( wp_kses( wp_html_excerpt( strip_shortcodes( get_the_content() ), 120, ' [...]' ), maxelectric_shortcode_allowhtmltags() ) ); ?>
											<a href="<?php the_permalink(); ?>" title="<?php esc_html_e('continue reading',"maxelectric-toolkit"); ?>">
												<?php esc_html_e('continue reading',"maxelectric-toolkit"); ?>
											</a>
										</div>
									</article>
								</div>
								<?php
							}
							$post_count++;
						endwhile;
						// Reset Post Data
						wp_reset_postdata();
					?>
				</div><!-- Row /- -->
			</div><!-- Container /- -->
		</div><!-- Latest Blog /- -->
		<?php
	}
	else if($layout == 'two') {
		query_posts('posts_per_page='.get_option('posts_per_page').'&paged='. get_query_var('paged') );
		
		if ( have_posts() ) {
			?>
			<div class="blog-listing">
				<?php
				// Start the loop.
				while ( have_posts() ) : the_post();

					// Include the page content template.
					get_template_part( "template-parts/content",get_post_format());

					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

				// End the loop.
				endwhile;
				
				// Previous/next page navigation.				
				the_posts_pagination( array(
					'prev_text'          => wp_kses( __( '<i class="fa fa-angle-double-left"></i> Prev', "maxelectric-toolkit" ), array( 'i' => array( 'class' => array() ) ) ),
					'next_text'          => wp_kses( __( 'Next <i class="fa fa-angle-double-right"></i>', "maxelectric-toolkit" ), array( 'i' => array( 'class' => array() ) ) ),
					'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', "maxelectric-toolkit" ) . ' </span>',
				) );		
				
				// Reset Query
				wp_reset_query();
				
				?>
			</div>
			<?php
		}
	}
	return ob_get_clean();
}

add_shortcode('maxelectric_blog', 'maxelectric_blog');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_blog',
		'name' => esc_html__( 'Blog Post', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select a Layout', "maxelectric-toolkit" ),
				'param_name' => 'layout',
				'description' => esc_html__( 'Default Layout 1 Set', 'maxelectric-toolkit' ),
				'value' => array(
					esc_html__( 'Layout 1', "maxelectric-toolkit" ) => 'one',
					esc_html__( 'Layout 2', "maxelectric-toolkit" ) => 'two',
				),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
				"dependency" => Array('element' => "layout", 'value' => array( 'one' ) ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Post Per Page Display", "maxelectric-toolkit"),
				"param_name" => "posts_display",
				"holder" => "div",
				"dependency" => Array('element' => "layout", 'value' => array( 'one' ) ),
			),
		),
	) );
}
?>