<?php
function maxelectric_contactus( $atts ) {
	
	extract( shortcode_atts( array( 'sc_title' => '', 'sc_desc' => '', 'id' => '','title' => '','sc_address' => '','sc_cnt_one' => '','sc_cnt_two' => '','sc_cnt_three' => '','sc_cnt_email' => '','sc_website' => '' ), $atts ) );
	
	ob_start();
	
	?>
	<!-- Contact Us -->
	<div class="contact-us container-fluid no-left-padding no-right-padding">
		<!-- Container -->
		<div class="container">
			<?php
				if( $sc_title != "" || $sc_desc != "" ) {
					?>
					<div class="contact-heading">
						<?php 
							if( $sc_title != "" ) { 
								?>
								<h5><?php echo esc_attr($sc_title); ?></h5>
								<?php 
							}
							echo wpautop( wp_kses( $sc_desc, maxelectric_shortcode_allowhtmltags() ) );
						?>
					</div>
					<?php
				}
			?>
			<!-- Row -->
			<div class="row">
				<div class="col-md-5 col-sm-5 col-xs-12">
					<table class="table table-bordered">
						<tbody>
							<?php
							if( $title != "" ) {
								?>
								<tr>
									<th><i class="fa fa-long-arrow-right"></i></th>
									<td><?php echo esc_attr( $title ); ?></td>
								</tr>
								<?php
							}
							if( $sc_address != "" ) {
								?>
								<tr>
									<th><i class="fa fa-map-marker"></i></th>
									<td><?php echo esc_attr( $sc_address ); ?></td>
								</tr>
								<?php
							}
							if( $sc_cnt_one != "" ) {
								?>
								<tr>
									<th><i class="fa fa-phone"></i></th>
									<td><a href="tel:<?php echo esc_html( str_replace(" ", "", $sc_cnt_one ) ); ?>" title="<?php echo esc_html( str_replace(" ", "", $sc_cnt_one ) ); ?>"><?php echo esc_html( $sc_cnt_one ); ?></a></td>
								</tr>
								<?php
							}
							if( $sc_cnt_two != "" ) {
								?>
								<tr>
									<th><i class="fa fa-mobile"></i></th>
									<td><a href="tel:<?php echo esc_html( str_replace(" ", "", $sc_cnt_two ) ); ?>" title="<?php echo esc_html( str_replace(" ", "", $sc_cnt_two ) ); ?>"><?php echo esc_html( $sc_cnt_two ); ?></a></td>
								</tr>
								<?php
							}
							if( $sc_cnt_three != "" ) {
								?>
								<tr>
									<th><i class="fa fa-phone-square"></i></th>
									<td><a href="tel:<?php echo esc_html( str_replace(" ", "", $sc_cnt_three ) ); ?>" title="<?php echo esc_html( str_replace(" ", "", $sc_cnt_three ) ); ?>"><?php echo esc_html( $sc_cnt_three ); ?></a></td>
								</tr>
								<?php
							}
							if( $sc_cnt_email != "" ) {
								?>
								<tr>
									<th><i class="fa fa-envelope"></i></th>
									<td><a href="mailto:<?php echo esc_html( $sc_cnt_email ); ?>" title="<?php echo esc_html( $sc_cnt_email ); ?>"><?php echo esc_html( $sc_cnt_email ); ?></a></td>
								</tr>
								<?php
							}
							if( $sc_website != "" ) {
								?>
								<tr>
									<th><i class="fa fa-globe"></i></th>
									<td><a href="<?php echo esc_url( $sc_website ); ?>"><?php echo esc_attr( $sc_website ); ?></a></td>
								</tr>
								<?php
							} ?>
						</tbody>
					</table>
				</div>
				<?php 
				if( $id != "" ) {
					?>
					<div class="col-md-7 col-sm-7 col-xs-12 no-padding">
						<?php echo do_shortcode('[contact-form-7 id="'.esc_attr( $id ).'"]'); ?>
					</div>
					<?php
				}
				?>
			</div><!-- Row /- -->
		</div><!-- Container /- -->
	</div><!-- Contact Us - -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_contactus', 'maxelectric_contactus');

if( function_exists('vc_map') ) {
	
	/**
	 * Add Shortcode To Visual Composer
	*/
	$maxelectric_cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );

	$maxelectric_contactforms = array();
	
	if ( $maxelectric_cf7 ) {
		foreach ( $maxelectric_cf7 as $cform ) {
			$maxelectric_contactforms[ $cform->post_title ] = $cform->ID;
		}
	} else {
		$maxelectric_contactforms[ esc_html__( 'No contact forms found', 'maxelectric-toolkit' ) ] = 0;
	}
	
	vc_map( array(
		'base' => 'maxelectric_contactus',
		'name' => esc_html__( 'Contact US', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
			array(
				'type' => 'textarea',
				'heading' => esc_html__( 'Short Description', "maxelectric-toolkit" ),
				'param_name' => 'sc_desc',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Company Name', "maxelectric-toolkit" ),
				'param_name' => 'title',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Address', "maxelectric-toolkit" ),
				'param_name' => 'sc_address',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Contact 1', "maxelectric-toolkit" ),
				'param_name' => 'sc_cnt_one',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Contact 2', "maxelectric-toolkit" ),
				'param_name' => 'sc_cnt_two',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Contact 3', "maxelectric-toolkit" ),
				'param_name' => 'sc_cnt_three',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Email Address', "maxelectric-toolkit" ),
				'param_name' => 'sc_cnt_email',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Website', "maxelectric-toolkit" ),
				'param_name' => 'sc_website',
			),
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select Contact Form', 'maxelectric-toolkit' ),
				'param_name' => 'id',
				'value' => $maxelectric_contactforms,
				'save_always' => true,
				'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'maxelectric-toolkit' ),
			),
		),
	) );
}
?>