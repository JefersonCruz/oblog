<?php
function maxelectric_testimonial( $atts ) {
	
	extract( shortcode_atts( array( 'sc_title' => '' ), $atts ) );
	
	ob_start();
	
	?>
	<!-- Testimonial Section -->
	<div class="testimonial-section no-left-padding no-right-padding container-fluid">
		<!-- Container -->
		<div class="container">
			<?php 
				if( $sc_title != "" ) {
					?>
					<!-- Section Header -->
					<div class="section-header">
						<h3><?php echo esc_attr($sc_title); ?></h3>
						<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
					</div><!-- Section Header /- -->
					<?php
				}
				if( maxelectric_options("opt_testimonial") != "" ) {
					?>	
					<!-- Row -->
					<div class="row">
						<div class="testimonial-carousel">
							<?php 
								foreach( maxelectric_options("opt_testimonial") as $single_item ) {
									?>
									<div class="col-md-12">
										<div class="testi-box">
											<?php 
												echo wp_get_attachment_image( $single_item["attachment_id"], 'maxelectric_82_82' ); 
												if( $single_item["title"] != "" ) {
													?>
													<h5><sup><?php esc_html_e('"',"maxelectric-toolkit"); ?></sup> <?php echo esc_attr($single_item["title"] ); ?></h5>
													<?php
												}
												if( $single_item["textOne"] != "" ) {
													?>
													<span><?php echo esc_attr($single_item["textOne"] ); ?></span>
													<?php
												}
												echo wpautop( wp_kses( $single_item["description"], maxelectric_shortcode_allowhtmltags() ) ); 
											?>
										</div>
									</div>
									<?php
								}
							?>
						</div>
					</div><!-- Row /- -->
					<?php
				}
			?>
		</div><!-- Container /- -->
	</div><!-- Testimonial Section /- -->	
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_testimonial', 'maxelectric_testimonial');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_testimonial',
		'name' => esc_html__( 'TestimonialTestimonial', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
		),
	) );
}
?>