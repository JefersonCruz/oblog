<?php
function maxelectric_about( $atts ) {
	
	extract( shortcode_atts( array( 'layout' => 'one','sc_title' => '','sc_image' => '' ), $atts ) );
	
	ob_start();
	
	if($layout == 'one') {
		?>
		<!-- About Section -->
		<div class="about-section no-left-padding no-right-padding container-fluid">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" ){
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
					?>
					<div class="row">
					<?php
					if( maxelectric_options("opt_aboutoneleft") != "" ) {
						?>
						<div class="col-md-4 col-sm-6 col-xs-6 about-content-left">
							<?php 
								foreach( maxelectric_options("opt_aboutoneleft") as $single_items ) {
									?>
									<div class="about-box">
										<?php 
											if( $single_items["textOne"] != "" || $single_items["title"] != "" ) {
												?>
												<h5>
													<?php 
														if($single_items["textOne"] != "" ) {
															?>
															<i class="<?php echo esc_attr($single_items["textOne"] ); ?>"></i>
															<?php
														}
														echo esc_attr($single_items["title"] );
													?>
												</h5>
												<?php 
											}	
											echo wpautop( wp_kses( $single_items["description"], maxelectric_shortcode_allowhtmltags() ) );
										?>
									</div>
									<?php
								}
							?>
						</div>
						<?php
					}
					if( maxelectric_options("opt_aboutoneright") != "" ) {
						?>
						<div class="col-md-4 col-sm-6 col-xs-6 about-content-right">
							<?php 
								foreach( maxelectric_options("opt_aboutoneright") as $single_item_right ) {
									?>
									<div class="about-box">
										<?php 
											if( $single_item_right["textOne"] != "" || $single_item_right["title"] != "" ) {
												?>
												<h5>
													<?php 
														if( $single_item_right["textOne"] != "" ) {
															?>
															<i class="<?php echo esc_attr($single_item_right["textOne"] ); ?>"></i>
															<?php
														}
														echo esc_attr( $single_item_right["title"] );
													?>
												</h5>
												<?php
											}
											echo wpautop( wp_kses( $single_item_right["description"], maxelectric_shortcode_allowhtmltags() ) );
										?>
									</div>
									<?php
								}
							?>
						</div>
						<?php
					}
					if( $sc_image != "" ){
						?>
						<div class="col-md-4 col-sm-12 col-xs-12 about-img">
							<?php echo wp_get_attachment_image($sc_image,'maxelectric_360_260'); ?>
						</div>
						<?php
					}
				?>
				</div>
			</div><!-- Container /- -->
		</div><!-- About Section -->
		<?php
	}
	else if($layout == 'two') {
		?>
		<!-- About Section2 -->
		<div class="about-section about-section2 no-left-padding no-right-padding container-fluid">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
					if( maxelectric_options("opt_about") != "" ) {
						?>
						<div class="col-md-8 col-sm-8 col-xs-12 about-content-left">
							<div class="row">
								<?php 
									foreach( maxelectric_options("opt_about") as $single ) {
										?>
										<div class="about-box col-md-6 col-sm-6 col-xs-12">
											<?php
												if( $single["textOne"] != "" || $single["title"] != "" )
													?>
													<h5>
														<?php
															if($single["textOne"] != "" ){
																?>
																<i class="<?php echo esc_attr($single["textOne"] ); ?>"></i>
																<?php 
															echo esc_attr($single["title"] );
														?>
													</h5>
													<?php
												}
												echo wpautop( wp_kses( $single["description"], maxelectric_shortcode_allowhtmltags() ) );
											?>
										</div>
										<?php
									}
								?>
							</div>
						</div>
						<?php
					}
					if($sc_image != "" ) {
						?>
						<div class="col-md-4 col-sm-4 col-xs-12 about-img">
							<?php echo wp_get_attachment_image($sc_image,'maxelectric_360_260'); ?>
						</div>
						<?php
					}
				?>
			</div><!-- Container /- -->
		</div><!-- About Section2 /- -->
		<?php
	}
	return ob_get_clean();
}

add_shortcode('maxelectric_about', 'maxelectric_about');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_about',
		'name' => esc_html__( 'About Us', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select a Layout', "maxelectric-toolkit" ),
				'param_name' => 'layout',
				'description' => esc_html__( 'Default Layout 1 Set', 'maxelectric-toolkit' ),
				'value' => array(
					esc_html__( 'Layout 1', "maxelectric-toolkit" ) => 'one',
					esc_html__( 'Layout 2', "maxelectric-toolkit" ) => 'two',
				),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two' ) ),
			),
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Image', "maxelectric-toolkit" ),
				'param_name' => 'sc_image',
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two' ) ),
			),
		),
	) );
}
?>