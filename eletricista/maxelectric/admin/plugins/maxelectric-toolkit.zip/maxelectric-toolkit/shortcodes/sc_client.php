<?php
function maxelectric_client( $atts ) {
	
	extract( shortcode_atts( array('sc_title' => '' ), $atts ) );
	
	ob_start();
	
	?>
	<!-- Clients -->
	<div class="clients container-fluid">
		<!-- Container -->
		<div class="container">
			<div class="row">
				<?php 
					if( $sc_title != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
					if( maxelectric_options("opt_client") != "" ) {
						?>
						<div class="clients-carousel">
							<?php 
								foreach( maxelectric_options("opt_client") as $single_item ) {
									?>
									<div class="col-md-12 item">
										<?php
											if($single_item["url"] != "" && $single_item["attachment_id"] != "" ) {
												?>
												<a href="<?php echo esc_url( $single_item["url"] ); ?>">
													<?php echo wp_get_attachment_image( $single_item["attachment_id"], 'full' ); ?>
												</a>
												<?php
											}
											elseif( $single_item["attachment_id"] != "" ) {
												echo wp_get_attachment_image( $single_item["attachment_id"], 'full' );
											}
										?>
									</div>
									<?php
								}
							?>
						</div>
						<?php
					}
				?>
			</div>
		</div><!-- Container /- -->
	</div><!-- Clients /- -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_client', 'maxelectric_client');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_client',
		'name' => esc_html__( 'Client', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
		),
	) );
}
?>