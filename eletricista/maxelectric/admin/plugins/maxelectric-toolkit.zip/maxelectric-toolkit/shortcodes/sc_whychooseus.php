<?php
function maxelectric_whychooseus( $atts ) {
	
	extract( shortcode_atts( array( 'sc_title' => '', 'sc_desc' => '' ), $atts ) );
	
	ob_start();
	
	?>
	<!-- Who We Are -->
	<div class="who-we-are no-left-padding no-right-padding container-fluid">
		<!-- Container -->
		<div class="container">
			<?php
				if( $sc_title != "" || $sc_desc != "" ) {
					?>
					<div class="why-choose-box">
						<?php 
							if( $sc_title != "" ) {
								?>
								<h5><?php echo esc_attr($sc_title); ?></h5>
								<?php
							}
							echo wpautop( wp_kses( $sc_desc, maxelectric_shortcode_allowhtmltags() ) );
						?>
					</div>
					<?php 
				}
				if( maxelectric_options("opt_whychoose") != "" ) {
					foreach( maxelectric_options("opt_whychoose") as $single_item ) {
						?>
						<div class="we-are-box">
							<?php
								if( $single_item["textOne"] != "" ) {
									?>
									<i class="<?php echo esc_attr( $single_item["textOne"] ); ?>"></i>
									<?php
								}
								if( $single_item["title"] != "" ) {
									?>
									<h5><?php echo esc_attr($single_item["title"] ); ?></h5>
									<?php
								}
								echo wpautop( wp_kses( $single_item["description"], maxelectric_shortcode_allowhtmltags() ) );
							?>
						</div>
						<?php
					}
				}
			?>
		</div>
	</div><!-- Who We Are /- -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_whychooseus', 'maxelectric_whychooseus');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_whychooseus',
		'name' => esc_html__( 'Why Choose US', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
			array(
				'type' => 'textarea',
				'heading' => esc_html__( 'Short Description', "maxelectric-toolkit" ),
				'param_name' => 'sc_desc',
			),
		),
	) );
}
?>