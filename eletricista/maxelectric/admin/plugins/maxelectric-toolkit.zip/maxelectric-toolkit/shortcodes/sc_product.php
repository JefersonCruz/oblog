<?php
function maxelectric_product( $atts ) {
	
	extract( shortcode_atts( array('sc_title' => '','posts_display' => '' ), $atts ) );
	
	if( '' === $posts_display ) :
		$posts_display = 4;		
	endif;
	
	/* Post Arguments */
	$args = array(
		'post_type' => 'product',
		'posts_per_page' => $posts_display,
	);

	$qry = new WP_Query( $args );
	
	ob_start();
	
	?>
	<!-- Product Section -->
	<div class="product-section no-left-padding no-right-padding container-fluid woocommerce">
		<!-- Container -->
		<div class="container">
			<?php
				if( $sc_title != "" ) {
					?>
					<!-- Section Header -->
					<div class="section-header">
						<h3><?php echo esc_attr($sc_title); ?></h3>
						<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
					</div><!-- Section Header /- -->
					<?php
				}
			?>
			<!-- Products -->
			<ul class="products">
				<?php
				while( $qry->have_posts() ) : $qry->the_post();
					global $product,$post;
					 wc_get_template_part( 'content','product' ); 
				endwhile;
				
				// Reset Original Data
				wp_reset_postdata();
			?>
			</ul><!-- Products /- -->
		</div><!-- Container /- -->
	</div><!-- Product Section /- -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_product', 'maxelectric_product');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_product',
		'name' => esc_html__( 'Product', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html("Post Per Page Display", "maxelectric-toolkit"),
				"param_name" => "posts_display",
				"holder" => "div",
			),
		),
	) );
}
?>