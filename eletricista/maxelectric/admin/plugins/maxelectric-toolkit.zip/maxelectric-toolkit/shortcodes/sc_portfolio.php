<?php
function maxelectric_portfolio( $atts ) {
	
	extract( shortcode_atts( array('layout' => 'one', 'sc_title' => '','posts_display' => '' ), $atts ) );
	
	$ow_post_type = 'maxele_portfolio';
	$ow_post_tax = 'maxelectric_portfolio_tax';
	
	$tax_args = array(
		'hide_empty' => false
	);

	if( '' === $posts_display ) :
		$posts_display = 8;		
	endif;
	
	$qry = new WP_Query( array(
		'post_type' => $ow_post_type,
		'posts_per_page' => $posts_display,
	) );
	
	$unexpected_str = array(" ","&","amp;",",",".","/");
	$terms = get_terms( $ow_post_tax, $tax_args );
	
	ob_start();
	
	if($layout == 'one') {
		?>
		<!-- Gallery Section -->
		<div class="gallery-section gallery1 container-fluid no-left-padding no-right-padding">
			<div class="gallery-header container-fluid">
				<!-- Container -->
				<div class="container">
					<?php 
						if( $sc_title !="" ) {
							?>
							<!-- Section Header -->
							<div class="section-header">
								<h3><?php echo esc_attr($sc_title); ?></h3>
								<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
							</div><!-- Section Header /- -->
						<?php
						}
					?>
					<ul id="filters" class="portfolio-categories no-left-padding">
						<li><a data-filter="*" class="active" href="#"><?php esc_html_e('All Projects',"maxelectric-toolkit"); ?></a></li>
						<?php
							if ( count( $terms > 0 ) && is_array( $terms ) ) {
								foreach ( $terms as $term ) {
									$termname = str_replace( $unexpected_str, '-', strtolower($term->name) );
									?>
									<li><a href="#" data-filter=".<?php echo esc_attr( $termname ); ?>"><?php echo esc_attr ( $term->name ); ?></a></li>						
									<?php
								}
							}
						?>
					</ul>
				</div><!-- Container /- -->
			</div>
			<ul class="portfolio-list no-left-padding">
				<?php
					while ( $qry->have_posts() ) : $qry->the_post();
					$taxonomies = "";
					$termsname = array();
					$terms_dashed = array();
					$terms = get_the_terms( get_the_ID(), $ow_post_tax );
					if ( count( $terms > 0 ) && is_array( $terms ) ) {
						foreach ( $terms as $term ) {
							$termsname[] = strtolower( $term->name );								
							$terms_dashed[] = str_replace( $unexpected_str, '-', strtolower( $term->name ) );
						}
						$taxonomies = implode(" ", $terms_dashed );
						$taxonomies_plus = implode(" + ", $termsname );
					}
					?>
					<li class="col-md-3 col-sm-4 col-xs-6 no-padding <?php echo esc_attr($taxonomies); ?>">
						<div class="content-image-block">
							<?php
								$url = esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) );
								if($url != "" ) {
									echo wp_oembed_get( $url );
								}
								else {
									the_post_thumbnail("maxelectric_476_477");
								}
							?>
							<div class="content-block-hover">
								<?php 
									if($url != "" ){
										?>
										<a class="popup-video" href="<?php echo esc_url(esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) ) ); ?>" title="<?php the_title(); ?>">
											<i class="icon icon-Search"></i>
										</a>
										<?php
									}
									else {
										?>
										<a class="zoom-in" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ); ?>" title="<?php the_title(); ?>">
											<i class="icon icon-Search"></i>
										</a>
										<?php
									}
								?>
								<h5>
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h5>
								<span>
									<?php
										$textonomys = get_the_terms( get_the_ID(), $ow_post_tax );
										if ( count( $textonomys > 0 ) && is_array( $textonomys ) ) {
											foreach ( $textonomys as $textonomy ) {
												$term_link = get_term_link( $textonomy );
												if ( is_wp_error( $term_link ) ) {
													continue;
												}
												echo '<a href="' . esc_url( $term_link ) . '">' . $textonomy->name . '</a>';
											}
										}
									?>
								</span>
							</div>
						</div>
					</li>
					<?php
					endwhile;
					// Reset Post Data
					wp_reset_postdata();
				?>
			</ul>
		</div><!-- Gallery Section /- -->
		<?php
	}
	elseif($layout == 'two') {
		?>
		<!-- Gallery Section2 -->
		<div class="gallery-section gallery-section2 container-fluid no-left-padding no-right-padding">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
				?>
				<ul id="filters" class="portfolio-categories no-left-padding">
					<li><a data-filter="*" class="active" href="#"><?php esc_html_e('All Projects',"maxelectric-toolkit"); ?></a></li>
					<?php
						if ( count( $terms > 0 ) && is_array( $terms ) ) {
							foreach ( $terms as $term ) {
								$termname = str_replace( $unexpected_str, '-', strtolower($term->name) );
								?>
								<li><a href="#" data-filter=".<?php echo esc_attr( $termname ); ?>"><?php echo esc_attr ( $term->name ); ?></a></li>						
								<?php
							}
						}
					?>
				</ul>
				<div class="row">
					<ul class="portfolio-list no-left-padding">
						<?php
							$port_count = 1;
							while ( $qry->have_posts() ) : $qry->the_post();
								$taxonomies = "";
								$termsname = array();
								$terms_dashed = array();
								$terms = get_the_terms( get_the_ID(), $ow_post_tax );
								if ( count( $terms > 0 ) && is_array( $terms ) ) {
									foreach ( $terms as $term ) {
										$termsname[] = strtolower( $term->name );								
										$terms_dashed[] = str_replace( $unexpected_str, '-', strtolower( $term->name ) );
									}
									$taxonomies = implode(" ", $terms_dashed );
									$taxonomies_plus = implode(" + ", $termsname );
								}
								$md_value = "";
									
								if( $port_count == 1 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 2 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 3 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 4 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 5 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 6 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 7 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 8 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								?>
								<li class="<?php echo esc_attr($md_value); ?> <?php echo esc_attr($taxonomies); ?> portfolio-<?php echo esc_attr($port_count); ?>">
									<div class="content-image-block">
										<?php 
											$url = esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) );
											if($url != "" ) {
												echo wp_oembed_get( $url );
											}
											else if($port_count == 1 ) {
												the_post_thumbnail('maxelectric_278_180');
											}
											else if( $port_count == 2 ) {
												the_post_thumbnail('maxelectric_278_180');
											}
											else if($port_count == 3 ||  $port_count == 5 ) {
												the_post_thumbnail('maxelectric_575_399');
											}
											else if($port_count == 4 ) {
												the_post_thumbnail('maxelectric_575_200');
											}
											else if($port_count == 6 || $port_count == 7 ) {
												the_post_thumbnail('maxelectric_278_150');
											}
											else if($port_count == 8  ) {
												the_post_thumbnail('maxelectric_575_250');
											}
										 ?>
										<div class="content-block-hover">
											<?php
												if($url != "" ){
													?>
													<a class="popup-video" href="<?php echo esc_url(esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) ) ); ?>" title="<?php the_title(); ?>">
														<i class="icon icon-Search"></i>
													</a>
													<?php
												}
												else {
													?>
													<a class="zoom-in" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ); ?>" title="<?php the_title(); ?>"><i class="icon icon-Search"></i></a>
													<?php
												}
											?>
											<a href="<?php the_permalink(); ?>" title="Link"><i class="icon icon-Linked"></i></a>
											<?php the_title('<h5>','</h5>'); ?>
										</div>
									</div>
								</li>
							<?php
							$port_count++;
							if( $port_count == 9 ) {
								$port_count = 1;
							}
							endwhile;
						// Reset Post Data
						wp_reset_postdata();
						?>
					</ul>
				</div>
			</div><!-- Container /- -->
		</div><!-- Gallery Section2 -->
		<?php
	}
	else if($layout == 'three') {
		?>
		<!-- Gallery Section2 -->
		<div class="gallery-section gallery-section2 container-fluid no-left-padding no-right-padding">
			<!-- Container -->
			<div class="container">
				<?php 
					if( $sc_title != "" ) {
						?>
						<!-- Section Header -->
						<div class="section-header">
							<h3><?php echo esc_attr($sc_title); ?></h3>
							<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
						</div><!-- Section Header /- -->
						<?php
					}
				?>
				<ul id="filters" class="portfolio-categories no-left-padding">
					<li><a data-filter="*" class="active" href="#"><?php esc_html_e('All Projects',"maxelectric-toolkit"); ?></a></li>
					<?php
						if ( count( $terms > 0 ) && is_array( $terms ) ) {
							foreach ( $terms as $term ) {
								$termname = str_replace( $unexpected_str, '-', strtolower($term->name) );
								?>
								<li><a href="#" data-filter=".<?php echo esc_attr( $termname ); ?>"><?php echo esc_attr ( $term->name ); ?></a></li>						
								<?php
							}
						}
					?>
				</ul>
				<div class="row">
					<ul class="portfolio-list no-left-padding">
						<?php
							query_posts('posts_per_page='.get_option('posts_per_page').'&paged='. get_query_var('paged') );
							$listargs = array(
								'post_type' => $ow_post_type,
							);
							$loop = new WP_Query( $listargs );
							
							$port_count = 1;
							
							while ( $loop->have_posts() ) : $loop->the_post();
								$taxonomies = "";
								$termsname = array();
								$terms_dashed = array();
								$terms = get_the_terms( get_the_ID(), $ow_post_tax );
								if ( count( $terms > 0 ) && is_array( $terms ) ) {
									foreach ( $terms as $term ) {
										$termsname[] = strtolower( $term->name );								
										$terms_dashed[] = str_replace( $unexpected_str, '-', strtolower( $term->name ) );
									}
									$taxonomies = implode(" ", $terms_dashed );
									$taxonomies_plus = implode(" + ", $termsname );
								}
								
								$md_value = "";
									
								if( $port_count == 1 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 2 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 3 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 4 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 5 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								elseif( $port_count == 6 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 7 ) {
									$md_value = "col-md-3 col-sm-6 col-xs-6";
								}
								elseif( $port_count == 8 ) {
									$md_value = "col-md-6 col-sm-6 col-xs-6 wide";
								}
								?>
								<li class="<?php echo esc_attr($md_value); ?> <?php echo esc_attr($taxonomies); ?> portfolio-<?php echo esc_attr($port_count); ?>">
									<div class="content-image-block">
										<?php
											$url = esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) );
											if($url != "" ) {
												echo wp_oembed_get( $url );
											}
											else if($port_count == 1 ||  $port_count == 2 ) {
												the_post_thumbnail('maxelectric_278_180');
											}
											else if($port_count == 3 ||  $port_count == 5 ) {
												the_post_thumbnail('maxelectric_575_399');
											}
											else if($port_count == 4 ) {
												the_post_thumbnail('maxelectric_575_200');
											}
											else if($port_count == 6 || $port_count == 7 ) {
												the_post_thumbnail('maxelectric_278_150');
											}
											else if($port_count == 8  ) {
												the_post_thumbnail('maxelectric_575_250');
											}
										 ?>
										<div class="content-block-hover">
											<?php
												if($url != "" ){
													?>
													<a class="popup-video" href="<?php echo esc_url(esc_url( get_post_meta( get_the_ID(), 'maxelectric_cf_portfolio_video_embed', 1 ) ) ); ?>" title="<?php the_title(); ?>">
														<i class="icon icon-Search"></i>
													</a>
													<?php
												}
												else {
													?>
													<a class="zoom-in" href="<?php echo esc_url(wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ) ); ?>" title="<?php the_title(); ?>"><i class="icon icon-Search"></i></a>
													<?php
												}
											?>
											<a href="<?php the_permalink(); ?>" title="Link"><i class="icon icon-Linked"></i></a>
											<?php the_title('<h5>','</h5>'); ?>
										</div>
									</div>
								</li>
								<?php
								$port_count++;
								if( $port_count == 9 ) {
									$port_count = 1;
								}
							endwhile;
							
							// Previous/next page navigation.				
							the_posts_pagination( array(
								'prev_text'          => wp_kses( __( '<i class="fa fa-angle-double-left"></i> Prev', "maxelectric-toolkit" ), array( 'i' => array( 'class' => array() ) ) ),
								'next_text'          => wp_kses( __( 'Next <i class="fa fa-angle-double-right"></i>', "maxelectric-toolkit" ), array( 'i' => array( 'class' => array() ) ) ),
								'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', "maxelectric-toolkit" ) . ' </span>',
							) );
						
						// Reset Query
						wp_reset_query();
						?>
					</ul>
				</div>
			</div><!-- Container /- -->
		</div><!-- Gallery Section2 -->
		<?php
	}
	return ob_get_clean();
}

add_shortcode('maxelectric_portfolio', 'maxelectric_portfolio');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_portfolio',
		'name' => esc_html__( 'Portfolio', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => esc_html__( 'Select a Layout', "maxelectric-toolkit" ),
				'param_name' => 'layout',
				'description' => esc_html__( 'Default Layout 1 Set', 'maxelectric-toolkit' ),
				'value' => array(
					esc_html__( 'Layout 1', "maxelectric-toolkit" ) => 'one',
					esc_html__( 'Layout 2', "maxelectric-toolkit" ) => 'two',
					esc_html__( 'Layout 3', "maxelectric-toolkit" ) => 'three',
				),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two','three' ) ),
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Post Per Page Display", "maxelectric-toolkit"),
				"param_name" => "posts_display",
				"holder" => "div",
				"dependency" => Array('element' => "layout", 'value' => array( 'one','two' ) ),
			),
		),
	) );
}
?>