<?php
function maxelectric_calltoaction( $atts ) {
	
	extract( shortcode_atts( array( 'sc_bg' => '', 'sc_title_a' => '', 'sc_title_b' => '', 'sc_title_c' => '', 'sc_desc' => '', 'btntxt' => '', 'btnurl' => '' ), $atts ) );
	
	if($sc_bg != ""){
		$style = " style='background-image: url(".wp_get_attachment_url( $sc_bg ).");'";
	}
	else {
		$style = "";
	}
	
	ob_start();
	
	?>
	<!-- Call Out -->
	<div class="call-out no-left-padding no-right-padding container-fluid"<?php echo html_entity_decode( $style ); ?>>
		<!-- Container -->
		<div class="container">
			<div class="call-out-content">
				<?php 
					if($sc_title_a != "" || $sc_title_b != "" || $sc_title_c != "" ) {
						?>
						<h5><?php echo esc_attr($sc_title_a); ?> <span><?php echo esc_attr($sc_title_b); ?></span> <?php echo esc_attr($sc_title_c); ?> </h5>
						<?php
					}
					echo wpautop( wp_kses( $sc_desc, maxelectric_shortcode_allowhtmltags() ) );
					
					if( $btntxt != "" ) {
						?>
						<a href="<?php echo esc_url($btnurl); ?>" title="<?php echo esc_attr($btntxt); ?>"><?php echo esc_attr($btntxt); ?></a>
						<?php
					}
				?>
			</div>
		</div><!-- Container /- -->
	</div><!-- Call Out /- -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_calltoaction', 'maxelectric_calltoaction');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_calltoaction',
		'name' => esc_html__( 'Call To Action', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Background Image', "maxelectric-toolkit" ),
				'param_name' => 'sc_bg',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title Text 1', "maxelectric-toolkit" ),
				'param_name' => 'sc_title_a',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title Text 2', "maxelectric-toolkit" ),
				'param_name' => 'sc_title_b',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title Text 3', "maxelectric-toolkit" ),
				'param_name' => 'sc_title_c',
			),
			array(
				'type' => 'textarea',
				'heading' => esc_html__( 'Short Description', "maxelectric-toolkit" ),
				'param_name' => 'sc_desc',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Button Text', "maxelectric-toolkit" ),
				'param_name' => 'btntxt',
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Button URL', "maxelectric-toolkit" ),
				'param_name' => 'btnurl',
			),
		),
	) );
}
?>