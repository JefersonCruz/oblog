<?php
function maxelectric_team( $atts ) {
	
	extract( shortcode_atts( array( 'sc_title' => '' ), $atts ) );
	
	ob_start();
	
	?>
	<!-- Team Section -->
	<div class="team-section no-left-padding no-right-padding container-fluid">
		<!-- Container -->
		<div class="container">
			<?php 
				if( $sc_title != "" ) {
					?>
					<!-- Section Header -->
					<div class="section-header">
						<h3><?php echo esc_attr($sc_title); ?></h3>
						<img src="<?php echo esc_url(MAXELECTRIC_LIB); ?>/images/seprator.png" alt="seprator" />
					</div><!-- Section Header /- -->
					<?php
				}
				if( maxelectric_options("opt_team") != "" ) {
					?>
					<div class="team-details-tab">
						<!-- Tab panes -->
						<div class="tab-content col-md-8 col-sm-8 col-xs-12">
							<?php 
								$cnt = 1;
								foreach( maxelectric_options("opt_team") as $single_item ) {
									$counter = rand(0,999);
									?>
									<div role="tabpanel" class="tab-pane <?php if($cnt == 2) { echo 'active'; } ?>" id="team-<?php echo esc_attr($cnt); ?>">
										<div class="col-md-5 col-sm-12 col-xs-12">
											<div class="tab-img">
												<?php echo wp_get_attachment_image( $single_item["attachment_id"], 'maxelectric_283_283' ); ?>
											</div>
											<ul class="team-social">
												<?php if( $single_item["textTwo"] != "" ) { ?><li><a href="<?php echo esc_url($single_item["textTwo"] ); ?>" target="_blank" title="Facebbok"><i class="fa fa-facebook"></i></a></li><?php } ?>
												<?php if( $single_item["textThree"] != "" ) { ?><li><a href="<?php echo esc_url($single_item["textThree"] ); ?>" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li><?php } ?>
												<?php if( $single_item["textFour"] != "" ) { ?><li><a href="<?php echo esc_url($single_item["textFour"] ); ?>" target="_blank" title="Google"><i class="fa fa-google"></i></a></li><?php } ?>
												<?php if( $single_item["textFive"] != "" ) { ?><li><a href="<?php echo esc_url($single_item["textFive"] ); ?>" target="_blank" title="linkedin"><i class="fa fa-linkedin"></i></a></li><?php } ?>
												<?php if( $single_item["textSix"] != "" ) { ?><li><a href="<?php echo esc_url($single_item["textSix"] ); ?>" target="_blank" title="Instagram"><i class="fa fa-instagram"></i></a></li><?php } ?>
											</ul>
										</div>
										<div class="col-md-7 cl-sm-12 col-xs-12">
											<div class="team-content">
												<?php
													if( $single_item["title"] != "" ) {
														?>
														<h5><?php echo esc_attr($single_item["title"] ); ?></h5>
														<?php
													}
													if( $single_item["textOne"] != "" ) {
														?>
														<span><?php echo esc_attr($single_item["textOne"] ); ?></span>
														<?php
													}
													echo wpautop( wp_kses( $single_item["description"], maxelectric_shortcode_allowhtmltags() ) ); 
													
													if( $single_item["textSeven"] != "" || $single_item["textEight"] != "" || $single_item["textNine"] != "" || $single_item["textTen"] != "" ) {
														?>
														<div id="skill_type-<?php echo esc_attr($cnt); ?>" class="skill-section">
															<?php
																if( $single_item["textSeven"] != "" || $single_item["textEight"] != "" ) {
																	?>
																	<div class="skill-progress-box">
																		<h3 class="block-title"><?php echo esc_attr($single_item["textSeven"] ); ?> <span data-skill_percent="<?php echo esc_attr($single_item["textEight"] ); ?>" id="skill_1_count-<?php echo esc_attr($counter); ?>"><?php echo esc_attr($single_item["textEight"] ); ?></span></h3>
																		<div class="progress">
																			<div class="progress-bar progress-bar-danger illustrator" role="progressbar" id="skill_bar_1_count-<?php echo esc_attr($counter); ?>"></div>
																		</div>
																	</div>
																	<?php
																}
																if( $single_item["textNine"] != "" || $single_item["textTen"] != "" ) {
																	?>
																	<div class="skill-progress-box">
																		<h3 class="block-title"><?php echo esc_attr($single_item["textNine"] ); ?> <span data-skill_percent="<?php echo esc_attr($single_item["textTen"] ); ?>" id="skill_1_count-<?php echo esc_attr($cnt); ?>"><?php echo esc_attr($single_item["textTen"] ); ?></span></h3>
																		<div class="progress">
																			<div class="progress-bar progress-bar-danger illustrator" role="progressbar" id="skill_bar_1_count-<?php echo esc_attr($cnt); ?>"></div>
																		</div>
																	</div>
																	<?php
																}
															?>
														</div>
														<?php
													}
												?>
											</div>
										</div>
									</div>
									<?php
								$cnt++;
								}
							?>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<?php 
									$cntcount = 1;
									foreach( maxelectric_options("opt_team") as $single_item ) {
										?>
										<li role="presentation" class="<?php if($cntcount == 2){ echo 'active'; } ?>">
											<a href="#team-<?php echo esc_attr($cntcount); ?>" aria-controls="team-<?php echo esc_attr($cntcount); ?>" role="tab" data-toggle="tab">
												<?php 
													if( $single_item["attachment_id"] != "" ) {
														?>
														<i>
															<?php echo wp_get_attachment_image( $single_item["attachment_id"], 'maxelectric_117_117' ); ?>
														</i>
														<?php
													}
													if( $single_item["title"] != "" ) {
														?>
														<h5><?php echo esc_attr($single_item["title"] ); ?></h5>
														<?php
													}
													if( $single_item["textOne"] != "" ) {
														?>
														<p><?php echo esc_attr($single_item["textOne"] ); ?></p>
														<?php
													}
												?>
											</a>
										</li>
										<?php
									$cntcount++;
									}
								?>
							</ul>
						</div>
					</div>
					<?php
				}
			?>
			
		</div><!-- Container /- -->
	</div><!-- Team Section /- -->
	<?php
	return ob_get_clean();
}

add_shortcode('maxelectric_team', 'maxelectric_team');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_team',
		'name' => esc_html__( 'Team', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Title', "maxelectric-toolkit" ),
				'param_name' => 'sc_title',
				'holder' => 'div',
			),
		),
	) );
}
?>