<?php
function maxelectric_counter( $atts ) {
	
	extract( shortcode_atts( array('sc_bg' => '' ), $atts ) );
	
	if($sc_bg != ""){
		$style = " style='background-image: url(".wp_get_attachment_url( $sc_bg ).");'";
	}
	else {
		$style = "";
	}
	
	ob_start();
	
	?>
	<!-- Counter Section -->
	<div class="counter-section no-left-padding no-right-padding container-fluid"<?php echo html_entity_decode( $style ); ?>>
		<!-- Container -->
		<div class="container">
			<div class="row">
				<?php 
					if( maxelectric_options("opt_counter") != "" ) {
						$i = 1;
						foreach( maxelectric_options("opt_counter") as $single_item ) {
							?>
							<div class="col-md-3 col-sm-4 col-xs-6 counter-block">
								<div class="counter-box">
									<?php
										if( $single_item["textOne"] != "" ) {
											?>
											<i class="<?php echo esc_attr($single_item["textOne"] ); ?>"></i>
											<?php
										}
									?>
									<span class="count" id="statistics_count-<?php echo esc_attr($i); ?>" data-statistics_percent="<?php echo esc_attr($single_item["textTwo"] ); ?>"> <?php esc_html_e('&nbsp;',"maxelectric-toolkit"); ?></span>
									<?php
										if( $single_item["title"] != "" ) {
											?>
											<p><?php echo esc_attr($single_item["title"] ); ?></p>
											<?php
										}
									?>	
								</div>
							</div>
							<?php
							$i++;
						}
					}
				?>
			</div>
		</div><!-- Container /- -->
	</div><!-- Counter Section /- -->
	<?php
	
	return ob_get_clean();
}

add_shortcode('maxelectric_counter', 'maxelectric_counter');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_counter',
		'name' => esc_html__( 'Counter/Skill', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Background Image', "maxelectric-toolkit" ),
				'param_name' => 'sc_bg',
			),
		),
	) );
}
?>