<?php
function maxelectric_map( $atts ) {
	
	extract( shortcode_atts( array( 'vc_map_lati' => '','vc_map_longi' => '', 'vc_address' => '', 'vc_marker' => '', 'vc_zoomlevel' => '' ), $atts ) );
	
	if( '' === $vc_zoomlevel ) :
		$vc_zoomlevel = 10;		
	endif;
	
	ob_start();
	
	if( $vc_map_lati != "" && $vc_map_longi != "" ) {
		?>
		<!-- Map Section -->
		<div class="map container-fluid no-left-padding no-right-padding">
			<div class="map-canvas" id="map-canvas-contact" data-lat="<?php echo esc_html( $vc_map_lati ); ?>" data-lng="<?php echo esc_html( $vc_map_longi ); ?>" data-string="<?php echo esc_html( $vc_address ); ?>" data-marker="<?php if($vc_marker !=''){ echo esc_url(wp_get_attachment_url($vc_marker,"full")); } else { echo esc_url( MAXELECTRIC_LIB ).'images/marker.png'; }?>" data-zoom="<?php echo esc_attr($vc_zoomlevel); ?>"></div>
		</div><!--  Map Section /- -->
		<?php
	}
	
	return ob_get_clean();
}

add_shortcode('maxelectric_map', 'maxelectric_map');

if( function_exists('vc_map') ) {

	vc_map( array(
		'base' => 'maxelectric_map',
		'name' => esc_html__( 'Google Map', "maxelectric-toolkit" ),
		'class' => '',
		"category" => esc_html__("Maxelectric Theme", "maxelectric-toolkit"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Map Latitute', "maxelectric-toolkit" ),
				'param_name' => 'vc_map_lati',
				"description" => esc_html("e.g : 40.730823", "maxelectric-toolkit"),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Map Longitute', "maxelectric-toolkit" ),
				'param_name' => 'vc_map_longi',
				"description" => esc_html("e.g : -73.997332", "maxelectric-toolkit"),
			),
			array(
				'type' => 'textfield',
				'heading' => esc_html__( 'Marker Address', "maxelectric-toolkit" ),
				'param_name' => 'vc_address',
				"description" => esc_html("e.g : Washington Square park, NY, United states.", "maxelectric-toolkit"),
				'holder' => 'div',
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Map ZoomLevel", "maxelectric-toolkit"),
				"param_name" => "vc_zoomlevel",
			),
			array(
				'type' => 'attach_image',
				'heading' => esc_html__( 'Marker Image', "maxelectric-toolkit" ),
				'param_name' => 'vc_marker',
			),
		),
	) );
}
?>